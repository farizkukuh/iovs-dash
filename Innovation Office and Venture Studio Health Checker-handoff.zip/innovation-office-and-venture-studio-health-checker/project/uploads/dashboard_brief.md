# IOVS Task Tracker — Executive Health Check

**Data source:** [IOVS - Task Tracker](https://www.notion.so/36881eaa07d980c2b23ac25b4085f9eb)
**Fields used:** `Task name` · `Status` · `Priority` · `Assignee` · `Due date` · `Past due` (formula) · `Task type` · `Started date` · `Completed date` · `Sprint` (formula)
**Last pulled:** 2026-05-24

---

## Dashboard Structure

Two views, toggled by a single switch at the top of the dashboard.

| View | Default | Purpose |
|------|---------|---------|
| **Main Dashboard** | Yes | Snapshot of current health — status, risk, workload, priorities, actions |
| **Timeline** | No | Chronological view — when tasks were started, when they are due, when they were completed, sprint progress |

Switching between views does not change the underlying data — only the lens through which it is presented.

---

## View 1 — Main Dashboard

The narrative arc runs top to bottom:

```
Summary → Health → Deadlines → Portfolio → Load → Priorities → Risks → Actions
```

---

### Summary

**Story question:** What are the 5 most important things to know right now?
**Visualization:** 5 highlight cards in a single row — each card is one finding, not one metric
**Notion fields:** `Status`, `Priority`, `Due date`, `Task type`

This is the first thing the viewer sees. It is not a repeat of the data below — it is a pre-digested verdict, pulling the single most critical signal from each downstream sub-section.

| # | Finding | Source sub-section | Data behind it |
|---|---------|-------------------|----------------|
| 1 | **16.7% complete.** 10 of 12 tasks are unfinished. | 1.1 Health | 2 Done / 4 In Progress / 6 Not Started |
| 2 | **3 high-priority tasks are due tomorrow.** All still in progress. | 1.2 Deadlines | Financial projection, Term Sheet, Claude skill — all due May 25 |
| 3 | **Harves+ has 0% completion.** 3 tasks, none started or in progress. | 1.3 Portfolio | 3 Not Started, 0 In Progress, 0 Done |
| 4 | **0 of 4 high-priority tasks are done.** 1 hasn't been started. | 1.5 Priorities | High: 0 Done, 3 In Progress, 1 Not Started |
| 5 | **1 high-priority task has no deadline.** It will never surface as urgent. | 1.6 Risks | China Market & Floxx — High priority, Not started, no Due date |

**UX rationale:** Viewers who have 10 seconds get the full story here. Viewers who have more time use this as an index — each card is a signpost pointing to the sub-section with the full picture. The cards are findings, not raw numbers, because a number without context requires the viewer to do work the dashboard should do for them.

---

### 1.1 — Here's Where We Stand

**Story question:** Are we OK?
**Visualization:** Metric cards — 3-up row · Donut chart (status split)
**Notion fields:** `Status`

| Metric | Value |
|--------|-------|
| Total tasks tracked | 12 |
| Done | 2 (16.7%) |
| In progress | 4 (33.3%) |
| Not started | 6 (50.0%) |
| Completion rate | 16.7% |

**Donut chart data:** Done 17% · In Progress 33% · Not Started 50%

**UX rationale:** Opens with the fewest possible numbers. The donut makes the 50% not-started proportion viscerally clear in a way the table cannot. Half the backlog hasn't been touched — that tension pulls the viewer forward.

---

### 1.2 — How Much Time Do We Have?

**Story question:** Are we running out of time?
**Visualization:** Single stacked bar (deadline wall) · Horizontal progress bars — urgency-ordered
**Notion fields:** `Due date`, `Past due`

| Time bucket | Tasks | % of total | Active (not Done) |
|-------------|-------|------------|-------------------|
| Overdue | 0 | 0% | 0 |
| Due tomorrow (May 25) | 3 | 25% | 3 |
| Due this week (May 26–30) | 8 | 67% | 6 |
| No due date | 1 | 8% | 1 |

**Tasks due tomorrow (Monday, May 25):**

| Task | Status | Priority | Portfolio |
|------|--------|----------|-----------|
| Financial projection until 2029 | In progress | High | Aquila |
| Term Sheet Development Aquila with SGPTech | In progress | High | Aquila |
| Claude cowork skill for IOVS | In progress | High | IOVS Function |

**Tasks with no due date:**

| Task | Status | Priority | Portfolio |
|------|--------|----------|-----------|
| China Market & Floxx Operational Immersion | Not started | High | Floxx |

**UX rationale:** No tasks are overdue today — but 3 high-priority tasks are due tomorrow, all still in progress. The stacked bar shows the full deadline wall at once. The urgency-ordered bars below break it into time buckets so the viewer can triage by window.

---

### 1.3 — Where Is the Work Actually Going?

**Story question:** How is effort distributed across portfolios?
**Visualization:** Horizontal stacked bar chart (Done / In Progress / Not Started per portfolio) · Donut chart (portfolio task share) · Summary data table
**Notion fields:** `Task type`, `Status`

| Portfolio | Total | Done | In progress | Not started | Completion % |
|-----------|-------|------|-------------|-------------|--------------|
| IOVS Function | 5 | 1 | 2 | 2 | 20% |
| Harves+ | 3 | 0 | 0 | 3 | 0% |
| Aquila - AI BOX | 2 | 0 | 2 | 0 | 0% |
| Floxx | 2 | 1 | 0 | 1 | 50% |
| **Total** | **12** | **2** | **4** | **6** | **16.7%** |

**Donut chart data (task share):** IOVS Function 42% · Harves+ 25% · Aquila 17% · Floxx 17%

**UX rationale:** The stacked bar reveals that Harves+ is entirely untouched — 3 tasks, 0 started. Aquila has 2 tasks in progress but 0 done, both due tomorrow. The donut above the chart surfaces IOVS Function's 42% concentration — a single portfolio carrying nearly half the workload. Floxx is the only portfolio with any completion.

---

### 1.4 — Who Is Carrying the Load?

**Story question:** Is the work spread fairly? Is anyone overloaded?
**Visualization:** Horizontal bar chart (tasks per assignee) · Status table with inline load badges
**Notion fields:** `Assignee`, `Status`, `Due date`

| Assignee | Tasks assigned | In progress | Due tomorrow | Load status |
|----------|---------------|-------------|--------------|-------------|
| Assignee A | 7 | 2 | 1 | Watch |
| Assignee B | 6 | 2 | 2 | Watch |
| Assignee C | 5 | 1 | 1 | Healthy |

> Assignee names resolve from Notion user IDs. 3 named users identified across 12 tasks. Tasks shared across multiple assignees are counted once per person.

**Load status thresholds:** Critical = >10 tasks or >3 overdue · Watch = 6–10 tasks or 1–2 overdue · Healthy = 3–5 tasks · Available = <3 tasks

**UX rationale:** Two assignees have tasks due tomorrow on high-priority items. No task is unassigned. The horizontal bar makes the load imbalance a visible shape — Assignee A at 7 vs Assignee C at 5. Placed after the portfolio view so the viewer already knows what work exists before finding out who is responsible for it.

---

### 1.5 — Are We Focused on the Right Things?

**Story question:** Do our priorities match what's actually getting done?
**Visualization:** Grouped bar chart (Priority × Status) · Priority matrix table with inline insight column
**Notion fields:** `Priority`, `Status`

| Priority | Total | Done | In progress | Not started | Insight |
|----------|-------|------|-------------|-------------|---------|
| High | 4 | 0 | 3 | 1 | 0 of 4 high-priority tasks completed. 1 not yet started. |
| Medium | 8 | 2 | 1 | 5 | 5 medium tasks haven't been touched. |

**High-priority tasks breakdown:**

| Task | Status | Due | Portfolio |
|------|--------|-----|-----------|
| Claude cowork skill for IOVS | In progress | May 25 | IOVS Function |
| Financial projection until 2029 | In progress | May 25 | Aquila |
| Term Sheet Development Aquila with SGPTech | In progress | May 25 | Aquila |
| China Market & Floxx Operational Immersion | Not started | No date | Floxx |

**UX rationale:** Zero high-priority tasks are done, and 3 of 4 are due tomorrow. The grouped bar makes the misalignment a shape rather than a table — the viewer sees the High column with nothing in Done at a glance. The Insight column delivers the verdict so the viewer doesn't have to calculate it.

---

### 1.6 — What's Actually at Risk Right Now?

**Story question:** What could go wrong this week?
**Visualization:** Risk flag table — action-oriented rows only · Cycle time histogram (when data accumulates)
**Notion fields:** `Priority`, `Status`, `Due date`, `Past due`, `Started date`, `Completed date`

| Risk condition | Count | Tasks affected | Required action |
|----------------|-------|----------------|-----------------|
| High-priority tasks due tomorrow | 3 | Financial projection, Term Sheet, Claude skill | Confirm delivery before end of day today |
| High-priority task with no due date | 1 | China Market & Floxx Immersion | Assign a deadline immediately |
| Portfolio with 0% progress (Harves+) | 3 | In-depth study Jala, JALA Competitive Analysis, Re-work venture plan | Unblock or reprioritize |
| Medium tasks not started, due this week | 5 | Project timeline, Note-taking template, JALA study, Re-work plan, IOVS org structure | Triage — which can realistically start this week? |

> No tasks are overdue as of May 24. The risk window opens tomorrow morning.

**UX rationale:** Positioned after the viewer has full context. Every row is a trigger with a required action — not an observation. The note is deliberate: the window is clean today, but that changes tomorrow.

---

### 1.7 — What Should We Do Right Now?

**Story question:** What are the most important actions before Monday morning?
**Visualization:** Tiered action cards — Critical / Important / Watch
**Notion fields:** All (derived from sub-sections 1.1–1.6)

**Critical — before end of day today (Sunday May 24)**
1. Confirm Financial projection until 2029 (High, Aquila, due May 25) will be delivered on time
2. Confirm Term Sheet Development with SGPTech (High, Aquila, due May 25) will be delivered on time
3. Confirm Claude cowork skill for IOVS (High, IOVS Function, due May 25) will be delivered on time

**Important — this week**
1. Assign a due date to China Market & Floxx Operational Immersion — High priority, no deadline
2. Start at least one Harves+ task — 0% completion, 3 tasks untouched
3. Triage the 5 unstarted medium tasks due May 29 — decide which are realistic this week

**Watch — track but not urgent yet**
1. Assignee A holds 7 tasks — monitor for overload if new tasks are added
2. IOVS Function has 2 unstarted tasks due May 29 — early enough to plan, late enough to monitor

**UX rationale:** The exit of the story. This section converts everything the viewer has absorbed into a ranked to-do list with a time horizon. The three tiers make the prioritization decision for the viewer rather than leaving it implicit.

---

### Reading Flow

| Depth | Sub-sections | Time | What the viewer leaves knowing |
|-------|-------------|------|-------------------------------|
| Glance | Summary only | 0–10 sec | 5 critical findings, pre-digested |
| Brief | Summary + 1.1–1.2 | 10–25 sec | + 16.7% done, 3 high-priority tasks due tomorrow |
| Deep dive | Summary + 1.1–1.6 | 25–60 sec | + Harves+ stalled, Aquila under pressure, no high-priority tasks done, China Market has no deadline |
| Full review | All sub-sections | 60+ sec | + Specific actions ranked by urgency with task names attached |

---

## View 2 — Timeline

**Trigger:** Toggle switch at top of dashboard — replaces the Main Dashboard view entirely.
**Story question:** When did things start, when are they due, and when were they completed?
**Notion fields:** `Started date`, `Due date`, `Completed date`, `Sprint`, `Status`, `Task type`, `Priority`

The Timeline view is not a summary — it is a chronological audit. It answers questions the Main Dashboard cannot: how long tasks have been in progress, whether due dates are clustered dangerously, and whether sprint throughput is improving over time.

---

### 2.1 — Task Timeline

**Visualization:** Gantt-style horizontal bar chart — one row per task
**Notion fields:** `Started date`, `Due date`, `Completed date`, `Status`, `Priority`, `Task type`

Each task is a horizontal bar from `Started date` to `Due date`. Completed tasks show a distinct end marker at `Completed date`. Tasks with no `Started date` appear as due-date markers only.

| Task | Started | Due | Completed | Duration (days) | Status |
|------|---------|-----|-----------|-----------------|--------|
| In-depth study Chickin | May 22 | May 29 | May 22 | 0 | Done |
| Set up workflow in Claude & Notion | May 22 | May 29 | May 22 | 0 | Done |
| IOVS organization structure | May 22 | May 29 | — | 2+ | In progress |
| Financial projection until 2029 | May 22 | May 25 | — | 2+ | In progress |
| Term Sheet Development Aquila | May 22 | May 25 | — | 2+ | In progress |
| Claude cowork skill for IOVS | May 22 | May 25 | — | 2+ | In progress |
| In-depth study Jala | — | May 29 | — | — | Not started |
| JALA Competitive Analysis | — | May 29 | — | — | Not started |
| China Market & Floxx Immersion | — | No date | — | — | Not started |
| Project timeline for each venture | — | May 29 | — | — | Not started |
| Financial projection until 2029 | — | May 29 | — | — | Not started |
| Standardized Note-Taking Template | — | May 29 | — | — | Not started |

**UX rationale:** The Gantt makes two things immediately visible that tables cannot: the gap between when tasks started and when they are due (time pressure), and the cluster of due dates on May 25 and May 29 (deadline concentration risk).

---

### 2.2 — Sprint Progress

**Visualization:** Grouped bar chart per sprint · Sprint burndown line chart
**Notion fields:** `Sprint`, `Status`, `Completed date`

| Sprint | Date range | Total tasks | Done | In progress | Not started | Completion % |
|--------|-----------|-------------|------|-------------|-------------|--------------|
| Sprint 1 | May 22 – Jun 4 | 12 | 2 | 4 | 6 | 16.7% |
| Sprint 2 | Jun 5 – Jun 18 | — | — | — | — | — |
| Sprint 3 | Jun 19 – Jul 2 | — | — | — | — | — |

> Sprint 2 and beyond will populate automatically as tasks are started after Jun 5. Sprint is derived from `Started date` — no manual input required.

**UX rationale:** The sprint view answers the throughput question: are we completing more tasks each sprint, or are backlogs growing? With only Sprint 1 data today, this chart is a placeholder — it becomes meaningful at the end of Sprint 1 (Jun 4) and comparative by Sprint 3.

---

### 2.3 — Velocity & Burndown

**Visualization:** Line chart (velocity over time) · Line chart (burndown within sprint)
**Notion fields:** `Completed date`, `Started date`, Sprint formula

**Velocity data (Completed date distribution):**

| Date | Tasks completed |
|------|----------------|
| May 22 | 2 (In-depth study Chickin, Set up workflow) |
| May 23 | 0 |
| May 24 | 0 |

> Velocity line chart will become meaningful after 2+ weeks. Current data shows 2 tasks completed on day 1, 0 since — the line is flat after the initial burst.

**UX rationale:** The velocity line shows direction over time — more useful than a completion percentage because it reveals whether the team is accelerating or stalling. The burndown shows tasks remaining within the current sprint window against an ideal pace line. Both charts are intentionally shown even while sparse — an empty chart communicates that tracking has started and data will accumulate.

---

### 2.4 — Cycle Time

**Visualization:** Histogram or dot plot — days from Started date to Completed date per task
**Notion fields:** `Started date`, `Completed date`

| Task | Started | Completed | Cycle time |
|------|---------|-----------|------------|
| In-depth study Chickin | May 22 | May 22 | 0 days |
| Set up workflow in Claude & Notion | May 22 | May 22 | 0 days |

> Only 2 tasks have both `Started date` and `Completed date` populated. Both completed on the same day as creation. Cycle time distribution requires more data points to be meaningful — the histogram will gain shape over time.

**UX rationale:** Cycle time surfaces slow tasks — the ones sitting In Progress for longer than expected. It also validates the `Started date` and `Completed date` fields are being populated consistently. Placed last in the Timeline view as it is the most analytical section, intended for managers rather than contributors.

---

## Visualization Audit

### Full chart inventory

| View | Sub-section | Chart type | Notion fields | Status |
|------|-------------|-----------|---------------|--------|
| Main | Summary | Highlight cards — 5-up row | `Status`, `Priority`, `Due date`, `Task type` | Ready |
| Main | 1.1 Health | Metric cards — 3-up row | `Status` | Ready |
| Main | 1.1 Health | Donut chart — status split | `Status` | Ready |
| Main | 1.2 Deadlines | Single stacked bar — deadline wall | `Due date` | Ready |
| Main | 1.2 Deadlines | Horizontal progress bars — urgency-ordered | `Due date`, `Past due` | Ready |
| Main | 1.3 Portfolio | Donut chart — portfolio task share | `Task type` | Ready |
| Main | 1.3 Portfolio | Horizontal stacked bar chart | `Task type`, `Status` | Ready |
| Main | 1.3 Portfolio | Summary data table | `Task type`, `Status` | Ready |
| Main | 1.4 Load | Horizontal bar chart — tasks per assignee | `Assignee` | Ready |
| Main | 1.4 Load | Status table with load badges | `Assignee`, `Status`, `Due date` | Ready |
| Main | 1.5 Priorities | Grouped bar chart — Priority × Status | `Priority`, `Status` | Ready |
| Main | 1.5 Priorities | Priority matrix table with insight column | `Priority`, `Status` | Ready |
| Main | 1.6 Risks | Risk flag table — action rows only | `Priority`, `Status`, `Due date`, `Past due` | Ready |
| Main | 1.6 Risks | Cycle time histogram | `Started date`, `Completed date` | Needs data (2 points today) |
| Main | 1.7 Actions | Tiered action cards — 3 severity levels | All (derived) | Ready |
| Timeline | 2.1 Task Timeline | Gantt-style horizontal bar chart | `Started date`, `Due date`, `Completed date` | Ready |
| Timeline | 2.2 Sprint Progress | Grouped bar chart per sprint | `Sprint`, `Status` | Sprint 1 only today |
| Timeline | 2.2 Sprint Progress | Sprint burndown line chart | `Sprint`, `Completed date` | Needs Sprint 1 end data |
| Timeline | 2.3 Velocity | Velocity line chart | `Completed date` | Sparse — 2 points |
| Timeline | 2.3 Velocity | Burndown within sprint | `Sprint`, `Completed date` | Sparse — needs 2+ weeks |
| Timeline | 2.4 Cycle Time | Histogram — days start to complete | `Started date`, `Completed date` | Needs data (2 points today) |

### Charts that grow richer over time

| Chart | Meaningful after | Why |
|-------|-----------------|-----|
| Velocity line | 2 weeks | Needs multiple completion events on different dates |
| Sprint comparison | End of Sprint 2 (Jun 18) | Needs 2 sprints to compare |
| Cycle time histogram | 5+ completed tasks | Distribution requires spread across multiple values |
| Burndown | Mid-sprint (Jun 4 midpoint) | Needs daily data within a sprint window |

---

## Technical Notes

- **Refresh:** Pull live from Notion on demand
- **Timestamp:** Auto-stamp header with pull date
- **Toggle:** Main Dashboard ↔ Timeline switch persists per session, resets on reload
- **Overdue logic:** Derived from `Past due` formula field in source database
- **Sprint logic:** Derived from `Started date` via formula — no manual input required. Sprint 1 = May 22 → Jun 4
- **Assignee names:** Stored as user IDs in Notion — resolve to display names when rendering
- **Storage:** Claude artifact or `dashboard/iovs-task-tracker.html` in GitHub
