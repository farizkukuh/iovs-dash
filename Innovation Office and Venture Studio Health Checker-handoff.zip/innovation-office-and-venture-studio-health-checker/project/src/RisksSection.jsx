// 1.6 — What's actually at risk right now?

function RisksSection() {
  const risks = [
    {
      icon: 'clock', tone: 'orange',
      condition: 'High-priority tasks due tomorrow',
      count: 3,
      tasks: ['Financial projection until 2029', 'Term Sheet · Aquila with SGPTech', 'Claude cowork skill for IOVS'],
      action: 'Confirm delivery before end of day today',
      cta: 'Confirm 3 deliveries',
    },
    {
      icon: 'flag', tone: 'red',
      condition: 'High-priority task with no due date',
      count: 1,
      tasks: ['China Market & Floxx Operational Immersion'],
      action: 'Assign a deadline immediately',
      cta: 'Pick a deadline',
    },
    {
      icon: 'pause', tone: 'orange',
      condition: 'Portfolio with 0% progress · Harves+',
      count: 3,
      tasks: ['In-depth study Jala', 'JALA Competitive Analysis', 'Re-work venture plan'],
      action: 'Unblock or reprioritize',
      cta: 'Open Harves+',
    },
    {
      icon: 'list', tone: 'neutral',
      condition: 'Medium tasks not started, due this week',
      count: 5,
      tasks: ['Project timeline', 'Note-taking template', 'JALA study', 'Re-work plan', 'IOVS org structure'],
      action: 'Triage — which can realistically start this week?',
      cta: 'Triage list',
    },
  ];

  return (
    <section data-screen-label="1.6 Risks" id="sec-risks">
      <SectionHeader
        eyebrow="1.6 · Risks"
        title="What’s actually at risk right now?"
        question="Every row is a trigger with a required action — not an observation. The window is clean today; it opens tomorrow."
        fields={['Priority', 'Status', 'Due date', 'Past due']} />

      <div className="card">
        <div className="card-head" style={{ alignItems: 'center' }}>
          <div>
            <div className="card-title">Risk flag table</div>
            <div className="card-sub">4 conditions tripped today · 0 overdue</div>
          </div>
          <div className="note" style={{ background: 'var(--bg-muted)', borderColor: 'var(--border-1)', maxWidth: 360 }}>
            <Icon name="info" size={14} style={{ color: 'var(--fg-2)', flexShrink: 0, marginTop: 2 }} />
            <div>No tasks overdue as of <b>May 24</b>. The risk window opens tomorrow morning.</div>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {risks.map((r, i) => (
            <RiskRow key={i} risk={r} />
          ))}
        </div>

        {/* Cycle-time histogram placeholder */}
        <div style={{
          marginTop: 22, paddingTop: 18, borderTop: '1px solid var(--border-1)',
          display: 'flex', alignItems: 'center', gap: 24,
        }}>
          <div style={{ flex: 1 }}>
            <div className="card-title">Cycle time histogram</div>
            <div className="card-sub" style={{ marginBottom: 12 }}>Distribution of days from Started → Completed</div>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, height: 60 }}>
              {[
                { d: '0d',  n: 2 }, { d: '1d', n: 0 }, { d: '2d', n: 0 },
                { d: '3d',  n: 0 }, { d: '5d', n: 0 }, { d: '7d', n: 0 },
                { d: '10d', n: 0 }, { d: '14d+', n: 0 },
              ].map((b, i) => (
                <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                  <div style={{
                    width: '100%', height: `${b.n * 24}px`, minHeight: 4,
                    background: b.n > 0 ? 'var(--garden-green)' : 'var(--bg-muted)',
                    borderRadius: '6px 6px 0 0',
                    display: 'flex', justifyContent: 'center', alignItems: 'flex-start',
                    color: '#fff', fontSize: 10, fontWeight: 700, paddingTop: 4,
                  }} className="num">
                    {b.n > 0 ? b.n : ''}
                  </div>
                  <div style={{ fontSize: 10, color: 'var(--fg-3)' }} className="num">{b.d}</div>
                </div>
              ))}
            </div>
          </div>
          <div style={{ width: 220, padding: 14, background: 'var(--bg-muted)', borderRadius: 14, fontSize: 12, color: 'var(--fg-2)' }}>
            <div className="section-eyebrow" style={{ marginBottom: 6 }}>Needs more data</div>
            Only 2 tasks have both Started + Completed dates. Both completed same day. Distribution will gain shape over time.
          </div>
        </div>
      </div>
    </section>
  );
}

function RiskRow({ risk }) {
  const palette = {
    red:     { bg: 'var(--status-danger-soft)', fg: 'var(--status-danger)' },
    orange:  { bg: 'var(--brand-orange-soft)',  fg: 'var(--brand-orange-press)' },
    neutral: { bg: 'var(--bg-muted)',           fg: 'var(--fg-2)' },
  }[risk.tone];

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '52px 1fr auto auto',
      gap: 16, alignItems: 'center',
      padding: '14px 16px',
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-1)',
      borderRadius: 'var(--radius-md)',
    }}>
      <div style={{
        width: 42, height: 42, borderRadius: 12,
        background: palette.bg, color: palette.fg,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name={risk.icon} size={18} />
      </div>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--fg-1)' }}>{risk.condition}</span>
          <span className="pill num" style={{ background: palette.bg, color: palette.fg }}>
            <span className="dot" style={{ background: palette.fg }} />{risk.count} affected
          </span>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 6 }}>
          {risk.tasks.map((t, i) => (
            <span key={i} style={{
              fontSize: 11, padding: '3px 8px',
              background: 'var(--bg-muted)', borderRadius: 999, color: 'var(--fg-2)',
            }}>{t}</span>
          ))}
        </div>
        <div style={{ fontSize: 12, color: palette.fg, fontWeight: 500 }}>
          <Icon name="arrow" size={11} style={{ verticalAlign: -1, marginRight: 4 }} />Required action: {risk.action}
        </div>
      </div>
      <div style={{ fontSize: 11, color: 'var(--fg-3)', textAlign: 'right' }}>
        <div className="section-eyebrow">Trigger</div>
        <div className="num" style={{ marginTop: 2 }}>auto</div>
      </div>
      <button style={{
        padding: '10px 16px', borderRadius: 999, border: 0,
        background: risk.tone === 'red' ? 'var(--status-danger)' : risk.tone === 'orange' ? 'var(--rich-soil)' : 'var(--bg-muted)',
        color: risk.tone === 'neutral' ? 'var(--fg-1)' : '#fff',
        fontSize: 12, fontWeight: 500, cursor: 'pointer',
        display: 'inline-flex', alignItems: 'center', gap: 6,
      }}>{risk.cta}<Icon name="arrow" size={12} /></button>
    </div>
  );
}

Object.assign(window, { RisksSection });
