// 1.7 — What should we do right now? Tiered action cards.

function ActionsSection() {
  const tiers = [
    {
      tone: 'critical',
      label: 'Critical',
      sub: 'Before end of day today · Sunday May 24',
      actions: [
        { task: 'Financial projection until 2029',          portfolio: 'Aquila - AI BOX', why: 'High · due May 25 · Dhanti' },
        { task: 'Term Sheet Aquila with SGPTech',           portfolio: 'Aquila - AI BOX', why: 'High · due May 25 · Indra' },
        { task: 'Claude cowork skill for IOVS',             portfolio: 'IOVS Function',   why: 'High · due May 25 · Kukuh' },
      ],
      verb: 'Confirm delivery on',
    },
    {
      tone: 'important',
      label: 'Important',
      sub: 'This week',
      actions: [
        { task: 'Assign a due date to China Market & Floxx', portfolio: 'Floxx',        why: 'High · no deadline' },
        { task: 'Start at least one Harves+ task',            portfolio: 'Harves+',      why: '0% completion · 3 untouched' },
        { task: 'Triage 5 unstarted medium tasks',            portfolio: 'Mixed',        why: 'all due May 29' },
      ],
      verb: 'Schedule',
    },
    {
      tone: 'watch',
      label: 'Watch',
      sub: 'Track but not urgent yet',
      actions: [
        { task: 'Kukuh Fariz holds 7 tasks',                  portfolio: 'Workload',     why: 'monitor if more is added' },
        { task: 'IOVS Function · 2 unstarted, due May 29',    portfolio: 'IOVS Function', why: 'early enough to plan' },
      ],
      verb: 'Monitor',
    },
  ];

  return (
    <section data-screen-label="1.7 Actions" id="sec-actions">
      <SectionHeader
        eyebrow="1.7 · Actions"
        title="What should we do right now?"
        question="The exit of the story. Everything you’ve absorbed, converted into a ranked to-do list with a time horizon."
        fields={['Derived from 1.1–1.6']} />

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {tiers.map(t => (
          <ActionTier key={t.label} tier={t} />
        ))}
      </div>
    </section>
  );
}

function ActionTier({ tier }) {
  const palette = {
    critical:  { bg: 'var(--rich-soil)',         fg: 'var(--white-pumpkin)', accent: '#E27000', tag: 'var(--brand-orange-soft)', tagFg: 'var(--brand-orange-press)' },
    important: { bg: 'var(--bg-elevated)',       fg: 'var(--fg-1)',          accent: '#2C9653', tag: 'var(--garden-green-soft)', tagFg: 'var(--garden-green-press)' },
    watch:     { bg: 'var(--bg-elevated)',       fg: 'var(--fg-1)',          accent: '#8FA294', tag: 'var(--bg-muted)',          tagFg: 'var(--fg-2)' },
  }[tier.tone];

  const inverse = tier.tone === 'critical';

  return (
    <div style={{
      background: palette.bg, color: palette.fg,
      borderRadius: 'var(--radius-xl)',
      border: '1px solid ' + (inverse ? 'rgba(255,255,255,0.06)' : 'var(--border-1)'),
      boxShadow: 'var(--shadow-sm)',
      padding: 22, position: 'relative', overflow: 'hidden',
      display: 'flex', flexDirection: 'column', gap: 18,
    }}>
      {/* glow */}
      {inverse && (
        <div style={{
          position: 'absolute', top: -80, right: -80, width: 220, height: 220, borderRadius: 999,
          background: 'radial-gradient(circle, rgba(226,112,0,0.40), transparent 70%)',
          pointerEvents: 'none',
        }} />
      )}

      <div style={{ position: 'relative' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
          <span style={{ width: 10, height: 10, borderRadius: 999, background: palette.accent }} />
          <span style={{
            fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 500,
            color: inverse ? 'rgba(239,239,231,0.6)' : 'var(--fg-3)',
          }}>Tier · {tier.tone}</span>
        </div>
        <div style={{
          fontSize: 26, fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.05,
          color: inverse ? 'var(--white-pumpkin)' : 'var(--fg-1)',
        }}>{tier.label}</div>
        <div style={{
          fontSize: 13, marginTop: 4,
          color: inverse ? 'rgba(239,239,231,0.7)' : 'var(--fg-2)',
        }}>{tier.sub}</div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, position: 'relative' }}>
        {tier.actions.map((a, i) => (
          <div key={i} style={{
            padding: '12px 14px',
            background: inverse ? 'rgba(255,255,255,0.04)' : 'var(--bg-muted)',
            borderRadius: 14,
            display: 'flex', flexDirection: 'column', gap: 6,
            border: inverse ? '1px solid rgba(255,255,255,0.08)' : '1px solid transparent',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{
                width: 22, height: 22, borderRadius: 999, flexShrink: 0,
                background: inverse ? 'rgba(255,255,255,0.10)' : 'var(--bg-elevated)',
                color: inverse ? 'var(--white-pumpkin)' : 'var(--fg-1)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 700,
              }} className="num">{i + 1}</span>
              <div style={{
                fontSize: 13, fontWeight: 600,
                color: inverse ? 'var(--white-pumpkin)' : 'var(--fg-1)',
              }}>{a.task}</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginLeft: 32 }}>
              <span style={{
                fontSize: 10, padding: '2px 8px',
                background: palette.tag, color: palette.tagFg,
                borderRadius: 999, fontWeight: 500,
              }}>{a.portfolio}</span>
              <span style={{
                fontSize: 11, color: inverse ? 'rgba(239,239,231,0.6)' : 'var(--fg-3)',
              }}>{a.why}</span>
            </div>
          </div>
        ))}
      </div>

      <button style={{
        marginTop: 'auto',
        background: palette.accent,
        color: '#fff', border: 0,
        padding: '12px 18px', borderRadius: 999,
        fontSize: 13, fontWeight: 500, cursor: 'pointer',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        position: 'relative',
      }}>
        {tier.verb} {tier.actions.length} item{tier.actions.length === 1 ? '' : 's'}
        <Icon name="arrow" size={14} />
      </button>
    </div>
  );
}

Object.assign(window, { ActionsSection });
