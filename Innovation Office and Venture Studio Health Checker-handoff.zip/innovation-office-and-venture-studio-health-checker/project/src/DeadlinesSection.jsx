// 1.2 — How much time do we have? Deadline wall + urgency-ordered bars + tomorrow's tasks.

function DeadlinesSection() {
  const dueTomorrow = TASKS.filter(t => t.due === '2026-05-25');
  const noDue = TASKS.filter(t => !t.due);

  return (
    <section data-screen-label="1.2 Deadlines" id="sec-deadlines">
      <SectionHeader
        eyebrow="1.2 · Deadlines"
        title="How much time do we have?"
        question="No tasks overdue today — but the wall opens tomorrow with 3 high-priority tasks still in progress."
        fields={['Due date', 'Past due']} />

      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 16 }}>
        {/* LEFT — Deadline wall + buckets */}
        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">Deadline wall</div>
              <div className="card-sub">Whole backlog placed against the next 7 days</div>
            </div>
            <span className="pill pill-progress"><span className="dot" />Risk opens tomorrow</span>
          </div>

          {/* Stacked bar */}
          <div style={{ display: 'flex', gap: 0, height: 56, borderRadius: 14, overflow: 'hidden', border: '1px solid var(--border-1)' }}>
            <Bucket label="Overdue"   count={0} pct={0}   color="var(--status-danger)" textColor="#fff" />
            <Bucket label="Tomorrow"  count={3} pct={25}  color="var(--brand-orange)"  textColor="#fff" />
            <Bucket label="This week" count={8} pct={66.7} color="var(--garden-green)" textColor="#fff" />
            <Bucket label="No date"   count={1} pct={8.3}  color="var(--sage-pumpkin)" textColor="var(--fg-1)" />
          </div>

          {/* Time-of-week scale */}
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8, fontSize: 10, color: 'var(--fg-3)' }}>
            <span>Today · Sun May 24</span>
            <span>Mon 25</span>
            <span>Tue 26</span>
            <span>Wed 27</span>
            <span>Thu 28</span>
            <span>Fri 29</span>
            <span>Sat 30</span>
          </div>

          {/* Urgency bars */}
          <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 14 }}>
            <UrgencyRow label="Overdue"             count={0} active={0} max={8} color="var(--status-danger)"   sub="No tasks past due"/>
            <UrgencyRow label="Due tomorrow · May 25" count={3} active={3} max={8} color="var(--brand-orange)"    sub="All In progress · all High"/>
            <UrgencyRow label="Due this week · May 26–30" count={8} active={6} max={8} color="var(--garden-green)" sub="2 already done, 6 active"/>
            <UrgencyRow label="No due date"          count={1} active={1} max={8} color="var(--sage-deep)"        sub="High priority — unanchored"/>
          </div>
        </div>

        {/* RIGHT — Tomorrow + No-date task list */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <div>
            <div className="card-head" style={{ marginBottom: 12 }}>
              <div>
                <div className="card-title" style={{ color: 'var(--brand-orange-press)' }}>
                  <Icon name="alert" size={14} />Due tomorrow · Mon May 25
                </div>
                <div className="card-sub">3 tasks · 100% still in progress · all High</div>
              </div>
              <span className="num" style={{
                fontSize: 36, fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--brand-orange)', lineHeight: 1,
              }}>3</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
              {dueTomorrow.map(t => (
                <TaskRow key={t.id} task={t} />
              ))}
            </div>
          </div>

          <div style={{ borderTop: '1px solid var(--border-1)', paddingTop: 18 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <div>
                <div className="card-title">
                  <Icon name="flag" size={14} />Tasks with no due date
                </div>
                <div className="card-sub">It will never surface as urgent</div>
              </div>
              <span className="num" style={{ fontSize: 22, fontWeight: 700, color: 'var(--fg-1)' }}>1</span>
            </div>
            {noDue.map(t => (
              <TaskRow key={t.id} task={t} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Bucket({ label, count, pct, color, textColor }) {
  if (pct === 0) return null;
  return (
    <div style={{
      width: `${pct}%`, background: color, color: textColor,
      display: 'flex', flexDirection: 'column', justifyContent: 'center',
      padding: '0 14px', position: 'relative',
      borderRight: '1px solid rgba(255,255,255,0.18)',
    }}>
      <div style={{ fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', opacity: 0.85 }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
        <span className="num" style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em' }}>{count}</span>
        <span style={{ fontSize: 11, opacity: 0.85 }} className="num">· {pct.toFixed(0)}%</span>
      </div>
    </div>
  );
}

function UrgencyRow({ label, count, active, max, color, sub }) {
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 5 }}>
        <div style={{ fontSize: 13, color: 'var(--fg-1)', fontWeight: 500 }}>{label}</div>
        <div className="num" style={{ fontSize: 12, color: 'var(--fg-3)' }}>
          <b style={{ color: 'var(--fg-1)' }}>{count}</b> task{count===1?'':'s'} · {active} active
        </div>
      </div>
      <HBar value={count} max={max} color={color} />
      <div style={{ fontSize: 11, color: 'var(--fg-3)', marginTop: 4 }}>{sub}</div>
    </div>
  );
}

function TaskRow({ task }) {
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '1fr auto auto',
      gap: 10,
      padding: '10px 0',
      borderBottom: '1px solid var(--border-1)',
      alignItems: 'center',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
        <AvatarGroup ids={task.assignees} size={26} />
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 13, color: 'var(--fg-1)', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {task.name}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 2 }}>
            <PortfolioChip name={task.portfolio} />
            <span style={{ fontSize: 11, color: 'var(--fg-3)' }}>{task.due ? `Due ${fmtDate(task.due)}` : 'No date'}</span>
          </div>
        </div>
      </div>
      <PriorityPill priority={task.priority} />
      <StatusPill status={task.status} />
    </div>
  );
}

Object.assign(window, { DeadlinesSection, TaskRow });
