// Small reusable atoms

function StatusPill({ status }) {
  const m = STATUS_META[status];
  if (!m) return null;
  return (
    <span className={`pill ${m.cls}`}>
      <span className="dot"></span>{status}
    </span>
  );
}

function PriorityPill({ priority }) {
  const m = PRIORITY_META[priority];
  if (!m) return null;
  return (
    <span className={`pill ${m.cls}`}>
      <span className="dot"></span>{priority}
    </span>
  );
}

function PortfolioChip({ name }) {
  const p = PORTFOLIOS[name];
  if (!p) return null;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      fontSize: 11, fontWeight: 500, padding: '3px 9px',
      borderRadius: 999, background: p.soft, color: p.color,
      letterSpacing: 0.02,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: 999, background: p.color }} />
      {name}
    </span>
  );
}

function AssigneeAvatar({ id, size = 26 }) {
  const a = ASSIGNEES[id];
  if (!a) return null;
  const initials = a.name.split(' ').map(s => s[0]).slice(0,2).join('');
  return (
    <span
      title={a.name}
      style={{
        width: size, height: size, borderRadius: 999,
        background: a.color, color: '#fff',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        fontWeight: 700, fontSize: size <= 24 ? 10 : 11,
        letterSpacing: 0.02, border: '2px solid #fff',
        boxSizing: 'border-box', flexShrink: 0,
      }}>{initials}</span>
  );
}

function AvatarGroup({ ids, size = 24, overlap = 8 }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center' }}>
      {ids.map((id, i) => (
        <span key={id} style={{ marginLeft: i === 0 ? 0 : -overlap, position: 'relative', zIndex: ids.length - i }}>
          <AssigneeAvatar id={id} size={size} />
        </span>
      ))}
    </span>
  );
}

function MiniDonut({ segments, size = 96, thickness = 14, centerLabel, centerSub }) {
  // segments: [{ value, color }]
  const total = segments.reduce((s, x) => s + x.value, 0) || 1;
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  let acc = 0;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} stroke="#EFEFE7" strokeWidth={thickness} fill="none" />
        {segments.map((seg, i) => {
          const len = (seg.value / total) * c;
          const dash = `${len} ${c - len}`;
          const offset = -acc;
          acc += len;
          return (
            <circle key={i}
              cx={size/2} cy={size/2} r={r}
              stroke={seg.color} strokeWidth={thickness}
              fill="none"
              strokeDasharray={dash}
              strokeDashoffset={offset}
              strokeLinecap="butt" />
          );
        })}
      </svg>
      {centerLabel && (
        <div style={{
          position: 'absolute', inset: 0, display: 'flex',
          flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          color: 'var(--fg-1)',
        }}>
          <div style={{ fontSize: size > 130 ? 30 : 22, fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1 }} className="num">{centerLabel}</div>
          {centerSub && <div style={{ fontSize: 10, color: 'var(--fg-3)', letterSpacing: 0.08, textTransform: 'uppercase', marginTop: 4 }}>{centerSub}</div>}
        </div>
      )}
    </div>
  );
}

function SectionHeader({ eyebrow, title, question, fields, charts }) {
  return (
    <div className="section-head">
      <div>
        <div className="section-eyebrow">{eyebrow}</div>
        <h2 className="section-title">{title}</h2>
        <div className="section-question">{question}</div>
      </div>
      <div className="section-meta">
        {fields && fields.length > 0 && fields.map(f => (
          <span key={f} className="section-tag" title={`Notion field: ${f}`}>
            <Icon name="dot" size={10} />{f}
          </span>
        ))}
      </div>
    </div>
  );
}

function HBar({ value, max, color = '#2C9653', height = 8, bg = '#EFEFE7' }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div style={{ background: bg, borderRadius: 999, height, overflow: 'hidden', width: '100%' }}>
      <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 999 }} />
    </div>
  );
}

function Legend({ items, columns = false }) {
  return (
    <div style={{
      display: columns ? 'grid' : 'flex',
      gridTemplateColumns: columns ? '1fr 1fr' : undefined,
      gap: columns ? '8px 18px' : 12,
      flexWrap: 'wrap',
    }}>
      {items.map((it, i) => (
        <div key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--fg-2)' }}>
          <span style={{ width: 10, height: 10, borderRadius: 3, background: it.color }} />
          <span style={{ color: 'var(--fg-1)', fontWeight: 500 }}>{it.label}</span>
          {it.value !== undefined && <span className="num" style={{ color: 'var(--fg-3)' }}>{it.value}</span>}
        </div>
      ))}
    </div>
  );
}

Object.assign(window, { StatusPill, PriorityPill, PortfolioChip, AssigneeAvatar, AvatarGroup, MiniDonut, SectionHeader, HBar, Legend });
