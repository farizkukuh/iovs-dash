// Outer page shell + top bar + view switch

const { useState: useStateShell } = React;

function Shell({ view, setView, children }) {
  return (
    <div className="iovs-page">
      <div className="iovs-sheet">
        <TopBar view={view} setView={setView} />
        <div className="iovs-content">{children}</div>
      </div>
    </div>);

}

function TopBar({ view, setView }) {
  return (
    <div className="iovs-topbar">
      {/* LEFT — brand */}
      <div className="iovs-brand">
        <div>
          <div className="iovs-brand-title">IOVS · Task tracker health</div>
          <div className="iovs-brand-sub">Innovation Office &amp; Venture Studio</div>
        </div>
        <div className="iovs-brand-source">
          <span className="iovs-source-dot"></span>
          Notion · live
        </div>
      </div>

      {/* CENTER — view switch */}
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <div className="iovs-switch" role="tablist">
          <button
            role="tab"
            aria-selected={view === 'main'}
            className={view === 'main' ? 'active' : ''}
            onClick={() => setView('main')}>
            <Icon name="grid" size={14} />Main dashboard
          </button>
          <button
            role="tab"
            aria-selected={view === 'timeline'}
            className={view === 'timeline' ? 'active' : ''}
            onClick={() => setView('timeline')}>
            <Icon name="timeline" size={14} />Timeline
          </button>
        </div>
      </div>

      {/* RIGHT — meta + identity */}
      <div className="iovs-toprightside">
        <div className="iovs-stamp">
          <div>Last pulled <b>Sun 24 May 2026</b></div>
          <div>via Notion MCP · live</div>
        </div>
        <button className="iovs-refresh" title="Pull again from Notion">
          <Icon name="refresh" size={16} />
        </button>
        <div className="iovs-brand-divider"></div>
        <img className="iovs-brand-logo" src={(window.__resources && window.__resources.japfaLogo) || "assets/japfa-logo.svg"} alt="JAPFA" />
      </div>
    </div>);

}

Object.assign(window, { Shell });