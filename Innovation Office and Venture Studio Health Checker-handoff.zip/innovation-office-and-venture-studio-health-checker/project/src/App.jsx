// App — top-level composition with view toggle

const { useState: useStateApp, useCallback } = React;

function App() {
  const [view, setView] = useStateApp('main');

  const jumpTo = useCallback((sec) => {
    const map = {
      health: 'sec-health',
      deadlines: 'sec-deadlines',
      portfolio: 'sec-portfolio',
      load: 'sec-load',
      priorities: 'sec-priorities',
      risks: 'sec-risks',
      actions: 'sec-actions',
    };
    const el = document.getElementById(map[sec]);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 24;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  }, []);

  return (
    <Shell view={view} setView={setView}>
      {view === 'main' ? <MainView jumpTo={jumpTo} /> : <TimelineView />}
    </Shell>
  );
}

function MainView({ jumpTo }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
      <Summary jumpTo={jumpTo} />
      <HealthSection />
      <DeadlinesSection />
      <PortfolioSection />
      <LoadSection />
      <PrioritiesSection />
      <RisksSection />
      <ActionsSection />

      {/* Footer: data fields used */}
      <div style={{
        marginTop: 8, paddingTop: 22,
        borderTop: '1px solid var(--border-1)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        fontSize: 11, color: 'var(--fg-3)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <img src={(window.__resources && window.__resources.japfaLogo) || "assets/japfa-logo.svg"} alt="" style={{ height: 18 }} />
          <span>Innovation Office &amp; Venture Studio · health check generated from Notion: IOVS — Task Tracker</span>
        </div>
        <div style={{ display: 'flex', gap: 14 }}>
          <span>Fields used: Task name · Status · Priority · Assignee · Due date · Past due · Task type · Started date · Completed date · Sprint</span>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
