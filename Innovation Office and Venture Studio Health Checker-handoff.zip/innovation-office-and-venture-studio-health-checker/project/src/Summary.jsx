// Summary — 5 highlight finding cards in a single row.
// Each card is one FINDING, pulled from a downstream sub-section.

function Summary({ jumpTo }) {
  const findings = [
    {
      kind: 'spotlight',
      eyebrow: 'Overall health',
      number: '16.7%',
      numberSub: 'complete',
      headline: '10 of 12 tasks are still unfinished.',
      ring: { done: 2, progress: 4, notStarted: 6 },
      jump: 'health',
      jumpLabel: 'See breakdown',
    },
    {
      kind: 'metric',
      eyebrow: 'Deadlines',
      icon: 'clock',
      tone: 'high',
      number: '3',
      numberSub: 'high-priority tasks due tomorrow',
      headline: 'All still in progress — confirm delivery today.',
      detailRows: ['Financial projection', 'Term Sheet · Aquila', 'Claude cowork skill'],
      jump: 'deadlines',
      jumpLabel: 'See deadline wall',
    },
    {
      kind: 'metric',
      eyebrow: 'Portfolio',
      icon: 'pause',
      tone: 'warning',
      number: '0%',
      numberSub: 'completion on Harves+',
      headline: '3 tasks, none started or in progress.',
      detailRows: ['Jala in-depth study', 'JALA competitive analysis', 'Re-work venture plan'],
      jump: 'portfolio',
      jumpLabel: 'See portfolio split',
    },
    {
      kind: 'metric',
      eyebrow: 'Priorities',
      icon: 'flag',
      tone: 'high',
      number: '0 / 4',
      numberSub: 'high-priority tasks done',
      headline: '1 hasn’t even been started yet.',
      detailRows: ['3 in progress, due tomorrow', '1 not started, no date'],
      jump: 'priorities',
      jumpLabel: 'See priority matrix',
    },
    {
      kind: 'metric',
      eyebrow: 'Risk',
      icon: 'alert',
      tone: 'warning',
      number: '1',
      numberSub: 'high-priority task with no deadline',
      headline: 'China Market & Floxx — will never surface as urgent.',
      detailRows: ['Assign a due date immediately'],
      jump: 'risks',
      jumpLabel: 'See risks',
    },
  ];

  return (
    <section data-screen-label="Summary">
      <SectionHeader
        eyebrow="01 · Summary"
        title="The 5 things to know right now"
        question="A pre-digested verdict — each card is one finding, not one metric. Tap to jump to the section behind it."
        fields={['Status', 'Priority', 'Due date', 'Task type']} />

      <div className="grid-5">
        {findings.map((f, i) => (
          <FindingCard key={i} finding={f} onJump={() => jumpTo && jumpTo(f.jump)} />
        ))}
      </div>
    </section>
  );
}

function FindingCard({ finding, onJump }) {
  const isSpotlight = finding.kind === 'spotlight';
  const toneColor = finding.tone === 'high' ? 'var(--status-danger)'
    : finding.tone === 'warning' ? 'var(--brand-orange)'
    : 'var(--garden-green)';

  return (
    <button
      onClick={onJump}
      style={{
        textAlign: 'left',
        background: isSpotlight ? 'var(--rich-soil)' : 'var(--bg-elevated)',
        color: isSpotlight ? 'var(--white-pumpkin)' : 'var(--fg-1)',
        border: isSpotlight ? '1px solid rgba(255,255,255,0.06)' : '1px solid var(--border-1)',
        boxShadow: 'var(--shadow-sm)',
        borderRadius: 'var(--radius-xl)',
        padding: 20,
        cursor: 'pointer',
        display: 'flex', flexDirection: 'column', gap: 10,
        position: 'relative', overflow: 'hidden',
        fontFamily: 'inherit',
        transition: 'transform 140ms var(--ease-out), box-shadow 140ms var(--ease-out)',
        minHeight: 240,
      }}
      onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = 'var(--shadow-md)'; }}
      onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = 'var(--shadow-sm)'; }}
    >
      {/* eyebrow row */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{
          fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 500,
          color: isSpotlight ? 'rgba(239,239,231,0.55)' : 'var(--fg-3)',
        }}>
          {finding.eyebrow}
        </div>
        {!isSpotlight && (
          <span style={{
            width: 26, height: 26, borderRadius: 999,
            background: finding.tone === 'high' ? 'var(--status-danger-soft)'
              : finding.tone === 'warning' ? 'var(--brand-orange-soft)'
              : 'var(--garden-green-soft)',
            color: toneColor,
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icon name={finding.icon} size={14} />
          </span>
        )}
      </div>

      {/* Number block */}
      <div>
        <div className="num" style={{
          fontSize: 44, fontWeight: 700, letterSpacing: '-0.03em', lineHeight: 1.0,
          color: isSpotlight ? 'var(--white-pumpkin)' : toneColor,
        }}>
          {finding.number}
        </div>
        <div style={{
          fontSize: 12, marginTop: 4,
          color: isSpotlight ? 'rgba(239,239,231,0.7)' : 'var(--fg-3)',
        }}>
          {finding.numberSub}
        </div>
      </div>

      {/* Headline */}
      <div style={{
        fontSize: 14, fontWeight: 500, lineHeight: 1.35,
        color: isSpotlight ? 'var(--white-pumpkin)' : 'var(--fg-1)',
        marginTop: 'auto',
      }}>
        {finding.headline}
      </div>

      {/* Detail */}
      {finding.detailRows && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4, paddingTop: 8, borderTop: '1px dashed ' + (isSpotlight ? 'rgba(255,255,255,0.12)' : 'var(--border-1)') }}>
          {finding.detailRows.map((r, i) => (
            <div key={i} style={{
              fontSize: 11, color: isSpotlight ? 'rgba(239,239,231,0.7)' : 'var(--fg-2)',
              display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <span style={{ width: 3, height: 3, borderRadius: 999, background: 'currentColor', opacity: 0.5 }} />
              {r}
            </div>
          ))}
        </div>
      )}

      {/* Spotlight: tiny ring */}
      {isSpotlight && finding.ring && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, paddingTop: 10, borderTop: '1px dashed rgba(255,255,255,0.12)' }}>
          <MiniDonut
            size={64} thickness={9}
            segments={[
              { value: finding.ring.done, color: '#2C9653' },
              { value: finding.ring.progress, color: '#B5DCC2' },
              { value: finding.ring.notStarted, color: '#6E5A50' },
            ]}
          />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4, fontSize: 11 }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: 'rgba(239,239,231,0.85)' }}>
              <span style={{ width: 8, height: 8, borderRadius: 999, background: '#2C9653' }} /> 2 done
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: 'rgba(239,239,231,0.85)' }}>
              <span style={{ width: 8, height: 8, borderRadius: 999, background: '#B5DCC2' }} /> 4 in progress
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: 'rgba(239,239,231,0.85)' }}>
              <span style={{ width: 8, height: 8, borderRadius: 999, background: '#6E5A50' }} /> 6 not started
            </span>
          </div>
        </div>
      )}

      {/* Footer link */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 6,
        fontSize: 11, fontWeight: 500, marginTop: 4,
        color: isSpotlight ? 'var(--brand-orange-soft)' : toneColor,
      }}>
        {finding.jumpLabel} <Icon name="chevronRight" size={12} />
      </div>
    </button>
  );
}

Object.assign(window, { Summary });
