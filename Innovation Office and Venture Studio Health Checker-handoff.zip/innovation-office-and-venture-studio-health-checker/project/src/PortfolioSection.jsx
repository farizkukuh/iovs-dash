// 1.3 — Where is the work actually going?

function PortfolioSection() {
  const rows = [
    { name: 'IOVS Function',   total: 5, done: 1, prog: 2, ns: 2, pct: 20 },
    { name: 'Harves+',         total: 3, done: 0, prog: 0, ns: 3, pct: 0 },
    { name: 'Aquila - AI BOX', total: 2, done: 0, prog: 2, ns: 0, pct: 0,  note: '2 in progress · 0 done · both due tomorrow' },
    { name: 'Floxx',           total: 2, done: 1, prog: 0, ns: 1, pct: 50 },
  ];

  return (
    <section data-screen-label="1.3 Portfolio" id="sec-portfolio">
      <SectionHeader
        eyebrow="1.3 · Portfolio"
        title="Where is the work actually going?"
        question="Harves+ is entirely untouched. Aquila — AI BOX has 2 in progress but 0 done — both due tomorrow."
        fields={['Task type', 'Status']} />

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 16 }}>
        {/* LEFT — task-share donut */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column' }}>
          <div className="card-head">
            <div>
              <div className="card-title">Workload share</div>
              <div className="card-sub">IOVS Function carries 42% of all tasks</div>
            </div>
            <span className="pill pill-notstarted">12 tasks</span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 22, flex: 1 }}>
            <MiniDonut
              size={180} thickness={28}
              segments={[
                { value: 5, color: '#2C9653' },
                { value: 3, color: '#B58750' },
                { value: 2, color: '#5C7A8C' },
                { value: 2, color: '#8FA294' },
              ]}
              centerLabel="42%"
              centerSub="iovs function"
            />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, flex: 1 }}>
              <DonutShareRow color="#2C9653" name="IOVS Function" pct="42%" n={5} />
              <DonutShareRow color="#B58750" name="Harves+"       pct="25%" n={3} />
              <DonutShareRow color="#5C7A8C" name="Aquila - AI BOX" pct="17%" n={2} />
              <DonutShareRow color="#8FA294" name="Floxx"         pct="17%" n={2} />
            </div>
          </div>
        </div>

        {/* RIGHT — stacked bar + table */}
        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">Status breakdown by portfolio</div>
              <div className="card-sub">Each bar is one portfolio · Done / In progress / Not started</div>
            </div>
            <Legend items={[
              { color: '#6B8E5A',  label: 'Done' },
              { color: '#2C9653',  label: 'In progress' },
              { color: '#B6C3B9',  label: 'Not started' },
            ]} />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            {rows.map(r => (
              <PortfolioBar key={r.name} row={r} />
            ))}
          </div>

          <div style={{
            marginTop: 22, paddingTop: 16, borderTop: '1px solid var(--border-1)',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12, color: 'var(--fg-2)',
          }}>
            <div>
              <b style={{ color: 'var(--fg-1)' }}>Floxx</b> is the only portfolio with any completion ·
              <b style={{ color: 'var(--brand-orange-press)' }}>&nbsp;Harves+</b> stalled at 0%
            </div>
            <span className="pill pill-progress">12 / 12 reconciled</span>
          </div>
        </div>
      </div>
    </section>
  );
}

function PortfolioBar({ row }) {
  const dW = (row.done / row.total) * 100;
  const pW = (row.prog / row.total) * 100;
  const nW = (row.ns / row.total) * 100;
  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: '160px 1fr 90px', gap: 14, alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
          <span style={{ width: 8, height: 24, borderRadius: 4, background: PORTFOLIOS[row.name]?.color || '#999' }} />
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--fg-1)' }}>{row.name}</div>
            <div style={{ fontSize: 11, color: 'var(--fg-3)' }} className="num">{row.total} task{row.total===1?'':'s'}</div>
          </div>
        </div>
        <div className="bar-track" style={{ height: 22 }}>
          {row.done > 0 && (
            <div style={{ width: `${dW}%`, background: '#6B8E5A', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 11, fontWeight: 700 }} className="num">{row.done}</div>
          )}
          {row.prog > 0 && (
            <div style={{ width: `${pW}%`, background: '#2C9653', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 11, fontWeight: 700 }} className="num">{row.prog}</div>
          )}
          {row.ns > 0 && (
            <div style={{ width: `${nW}%`, background: '#B6C3B9', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--fg-1)', fontSize: 11, fontWeight: 700 }} className="num">{row.ns}</div>
          )}
        </div>
        <div className="num" style={{ textAlign: 'right', fontSize: 18, fontWeight: 700, color: row.pct === 0 ? 'var(--brand-orange-press)' : 'var(--fg-1)', letterSpacing: '-0.02em' }}>
          {row.pct}%
        </div>
      </div>
      {row.note && (
        <div style={{ marginLeft: 174, marginTop: 6, fontSize: 11, color: 'var(--brand-orange-press)' }}>
          <Icon name="alert" size={10} style={{ verticalAlign: -1 }} /> {row.note}
        </div>
      )}
    </div>
  );
}

function DonutShareRow({ color, name, pct, n }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <span style={{ width: 10, height: 10, borderRadius: 3, background: color }} />
      <span style={{ flex: 1, fontSize: 13, fontWeight: 500, color: 'var(--fg-1)' }}>{name}</span>
      <span className="num" style={{ fontSize: 12, color: 'var(--fg-3)' }}>{n}</span>
      <span className="num" style={{ fontSize: 13, fontWeight: 700, color: 'var(--fg-1)', minWidth: 40, textAlign: 'right' }}>{pct}</span>
    </div>
  );
}

Object.assign(window, { PortfolioSection });
