// 1.5 — Are we focused on the right things? Grouped bar + priority matrix.

function PrioritiesSection() {
  const highTasks = TASKS.filter(t => t.priority === 'High');

  return (
    <section data-screen-label="1.5 Priorities" id="sec-priorities">
      <SectionHeader
        eyebrow="1.5 · Priorities"
        title="Are we focused on the right things?"
        question="Zero High tasks are done. 3 of 4 are due tomorrow. The High column has nothing in Done at a glance."
        fields={['Priority', 'Status']} />

      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 16, alignItems: 'stretch' }}>
        {/* LEFT — quadrant scatter */}
        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">Priority × Status quadrant</div>
              <div className="card-sub">High &amp; not-started = critical gap · 12 dots, one per task</div>
            </div>
            <Legend items={[
              { color: '#6B8E5A', label: 'Done' },
              { color: '#2C9653', label: 'In progress' },
              { color: '#B6C3B9', label: 'Not started' },
            ]} />
          </div>

          <QuadrantScatter />

          <div style={{
            marginTop: 22, paddingTop: 16, borderTop: '1px solid var(--border-1)',
            display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12,
          }}>
            <InsightTile
              tone="danger"
              big="0"
              of="of 4"
              label="High priority tasks completed"
              note="1 not even started"
            />
            <InsightTile
              tone="warning"
              big="5"
              of="of 8"
              label="Medium tasks not touched"
              note="due May 29 · need triage"
            />
          </div>
        </div>

        {/* RIGHT — priority matrix table */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column' }}>
          <div className="card-head">
            <div>
              <div className="card-title">High-priority breakdown</div>
              <div className="card-sub">Every High task, where it stands, what’s blocking</div>
            </div>
            <span className="pill pill-high"><span className="dot" />4 tasks</span>
          </div>

          <table className="dtable">
            <thead>
              <tr>
                <th>Task</th>
                <th>Status</th>
                <th>Due</th>
              </tr>
            </thead>
            <tbody>
              {highTasks.map(t => (
                <tr key={t.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <AvatarGroup ids={t.assignees} size={24} />
                      <div>
                        <div style={{ fontWeight: 600, fontSize: 13 }}>{t.name}</div>
                        <div style={{ marginTop: 3 }}>
                          <PortfolioChip name={t.portfolio} />
                        </div>
                      </div>
                    </div>
                  </td>
                  <td><StatusPill status={t.status} /></td>
                  <td>
                    <div className="num" style={{ fontWeight: 600, fontSize: 13, color: t.due ? 'var(--fg-1)' : 'var(--status-danger)' }}>
                      {t.due ? fmtDate(t.due) : 'No date'}
                    </div>
                    <div style={{ fontSize: 10, color: 'var(--fg-3)' }}>
                      {t.due === '2026-05-25' ? 'in 1 day' : t.due ? 'in 5 days' : '—'}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Footer: who carries the High pile */}
          <div style={{
            marginTop: 'auto', paddingTop: 18,
            borderTop: '1px solid var(--border-1)',
          }}>
            <div className="section-eyebrow" style={{ marginBottom: 10 }}>Who carries the High pile</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {['A', 'B', 'C'].map(id => {
                const mine = TASKS.filter(t => t.priority === 'High' && t.assignees.includes(id));
                const a = ASSIGNEES[id];
                return (
                  <div key={id} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <AssigneeAvatar id={id} size={26} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--fg-1)' }}>{a.name}</div>
                      <div style={{ fontSize: 11, color: 'var(--fg-3)' }}>
                        {mine.length === 0 ? 'No High tasks' : mine.map(t => t.name.split(' ').slice(0, 2).join(' ') + (t.name.split(' ').length > 2 ? '…' : '')).join(' · ')}
                      </div>
                    </div>
                    <span className="num" style={{
                      fontSize: 20, fontWeight: 700, color: mine.length > 0 ? 'var(--status-danger)' : 'var(--fg-4)',
                      letterSpacing: '-0.02em',
                    }}>{mine.length}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function QuadrantScatter() {
  // Plot every task. X = priority (Medium left, High right). Y = status (Not started bottom, Done top).
  // Quadrants split at the priority axis midline and at the in-progress / not-started Y line.
  const W = 460, H = 230;
  const pad = { l: 78, r: 20, t: 26, b: 44 };
  const innerW = W - pad.l - pad.r;
  const innerH = H - pad.t - pad.b;

  // X positions for priority columns (Medium, High)
  const priX = { Medium: pad.l + innerW * 0.27, High: pad.l + innerW * 0.73 };
  // Y positions per status row (top = Done)
  const statY = {
    'Done':        pad.t + innerH * 0.18,
    'In progress': pad.t + innerH * 0.50,
    'Not started': pad.t + innerH * 0.85,
  };
  const statColor = { 'Done': '#6B8E5A', 'In progress': '#2C9653', 'Not started': '#B6C3B9' };

  // Quadrant boundaries
  const midX = pad.l + innerW * 0.50;
  const midY = pad.t + innerH * 0.67; // between In progress and Not started

  // Group tasks by (priority, status) so we can offset overlapping dots in a small cluster.
  const cells = {};
  TASKS.forEach(t => {
    const key = t.priority + '|' + t.status;
    (cells[key] ||= []).push(t);
  });

  // Compute (x, y) for each task, jittered radially around the cell center.
  const placed = [];
  Object.entries(cells).forEach(([key, group]) => {
    const [pri, stat] = key.split('|');
    const cx = priX[pri], cy = statY[stat];
    group.forEach((t, i) => {
      const n = group.length;
      // simple ring layout
      let dx = 0, dy = 0;
      if (n === 1) { dx = 0; dy = 0; }
      else {
        const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
        const r = n <= 4 ? 5 : 8;
        dx = Math.cos(angle) * r;
        dy = Math.sin(angle) * r;
      }
      placed.push({ task: t, x: cx + dx, y: cy + dy, color: statColor[stat] });
    });
  });

  return (
    <div style={{ position: 'relative' }}>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{ display: 'block' }}>
        {/* Quadrant fills */}
        <rect x={pad.l}   y={pad.t}  width={midX - pad.l} height={midY - pad.t}     fill="var(--bg-tint)"            opacity="0.7"/>
        <rect x={midX}    y={pad.t}  width={W - pad.r - midX} height={midY - pad.t} fill="var(--garden-green-wash)" opacity="0.9"/>
        <rect x={pad.l}   y={midY}   width={midX - pad.l} height={H - pad.b - midY} fill="var(--bg-muted)"          opacity="0.6"/>
        <rect x={midX}    y={midY}   width={W - pad.r - midX} height={H - pad.b - midY} fill="var(--status-danger-soft)" opacity="0.6"/>

        {/* Quadrant borders */}
        <rect x={pad.l} y={pad.t} width={innerW} height={innerH} fill="none" stroke="var(--border-1)" strokeWidth="1" />
        <line x1={midX} x2={midX} y1={pad.t} y2={H - pad.b} stroke="var(--border-2)" strokeDasharray="3 4" />
        <line x1={pad.l} x2={W - pad.r} y1={midY} y2={midY} stroke="var(--border-2)" strokeDasharray="3 4" />

        {/* Quadrant labels (top-corner whisper text) */}
        <text x={pad.l + 8} y={pad.t + 12} fontSize="7" fill="#9B8A82" letterSpacing="0.1em" textAnchor="start">
          BACKGROUND MOTION
        </text>
        <text x={W - pad.r - 8} y={pad.t + 12} fontSize="7" fill="#1E6739" fontWeight="600" letterSpacing="0.1em" textAnchor="end">
          ACTIVE HIGH ⓘ
        </text>
        <text x={pad.l + 8} y={H - pad.b - 6} fontSize="7" fill="#9B8A82" letterSpacing="0.1em" textAnchor="start">
          COLD BACKLOG
        </text>
        <text x={W - pad.r - 8} y={H - pad.b - 6} fontSize="7" fontWeight="700" fill="#8A3727" letterSpacing="0.1em" textAnchor="end">
          ⚠ CRITICAL GAP
        </text>

        {/* Y axis tick rows */}
        {Object.entries(statY).map(([label, y]) => (
          <g key={label}>
            <text x={pad.l - 8} y={y + 3} fontSize="9" fill="#6E5A50" textAnchor="end" fontWeight="500">{label}</text>
            <circle cx={pad.l} cy={y} r="2" fill="#BFB1A8" />
          </g>
        ))}

        {/* X axis priority labels */}
        {Object.entries(priX).map(([label, x]) => (
          <g key={label}>
            <text x={x} y={H - pad.b + 18} fontSize="10" fontWeight="700" fill="#3B2F2A" textAnchor="middle">{label}</text>
            <text x={x} y={H - pad.b + 30} fontSize="9" fill="#9B8A82" textAnchor="middle" className="num">
              {TASKS.filter(t => t.priority === label).length} total
            </text>
          </g>
        ))}

        {/* Axis names */}
        <text x={(pad.l + W - pad.r) / 2} y={H - 3} fontSize="7" fill="#9B8A82" textAnchor="middle" letterSpacing="0.14em">PRIORITY →</text>

        {/* Dots */}
        {placed.map((p, i) => (
          <g key={i}>
            <circle cx={p.x} cy={p.y} r="3"
              fill={p.color}
              stroke="#fff" strokeWidth="1" />
            <title>{p.task.name} · {p.task.priority} · {p.task.status} · {p.task.assignees.map(a => ASSIGNEES[a].name.split(' ')[0]).join(', ')}</title>
          </g>
        ))}
      </svg>

      {/* Quadrant counts strip */}
      <div style={{
        marginTop: 12,
        display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8,
        fontSize: 11,
      }}>
        <QuadCount label="Cold backlog"      n={5} color="#9B8A82" />
        <QuadCount label="Background motion" n={3} color="#6E5A50" />
        <QuadCount label="Active high"       n={3} color="#1E6739" />
        <QuadCount label="Critical gap"      n={1} color="#8A3727" highlight />
      </div>
    </div>
  );
}

function QuadCount({ label, n, color, highlight }) {
  return (
    <div style={{
      padding: '8px 10px',
      borderRadius: 10,
      background: highlight ? 'var(--status-danger-soft)' : 'var(--bg-muted)',
      display: 'flex', alignItems: 'center', gap: 8,
    }}>
      <span className="num" style={{ fontSize: 18, fontWeight: 700, color, letterSpacing: '-0.02em', lineHeight: 1 }}>{n}</span>
      <span style={{ fontSize: 10, color: 'var(--fg-2)', letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 500 }}>{label}</span>
    </div>
  );
}

function InsightTile({ tone, big, of, label, note }) {
  const color = tone === 'danger' ? 'var(--status-danger)' : 'var(--brand-orange)';
  const soft = tone === 'danger' ? 'var(--status-danger-soft)' : 'var(--brand-orange-soft)';
  return (
    <div style={{
      background: soft, borderRadius: 'var(--radius-md)',
      padding: '12px 14px',
      display: 'flex', flexDirection: 'column', gap: 4,
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
        <span className="num" style={{ fontSize: 30, fontWeight: 700, letterSpacing: '-0.02em', color, lineHeight: 1 }}>{big}</span>
        <span style={{ fontSize: 11, color, opacity: 0.7 }} className="num">{of}</span>
      </div>
      <div style={{ fontSize: 12, color: 'var(--fg-1)', fontWeight: 500 }}>{label}</div>
      <div style={{ fontSize: 11, color: 'var(--fg-2)' }}>{note}</div>
    </div>
  );
}

Object.assign(window, { PrioritiesSection });
