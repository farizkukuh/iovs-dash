// 1.4 — Who is carrying the load? Horizontal bars + status table.

function LoadSection() {
  const sharedTasks = TASKS.filter(t => t.assignees.length > 1).length;
  function statusFor(n) {
    if (n > 10) return 'Critical';
    if (n >= 6) return 'Watch';
    if (n >= 3) return 'Healthy';
    return 'Available';
  }
  const rows = [
    { id: 'A', ...loadFor('A') },
    { id: 'B', ...loadFor('B') },
    { id: 'C', ...loadFor('C') },
  ].map(r => ({ ...r, prog: r.inProgress, due: r.dueTomorrow, status: statusFor(r.total) }))
   .sort((a, b) => b.total - a.total);

  return (
    <section data-screen-label="1.4 Load" id="sec-load">
      <SectionHeader
        eyebrow="1.4 · Load"
        title="Who’s carrying the load?"
        question="Two assignees have High-priority tasks due tomorrow. No task is unassigned."
        fields={['Assignee', 'Status', 'Due date']} />

      <div style={{ display: 'grid', gridTemplateColumns: '1.05fr 1fr', gap: 16 }}>
        {/* LEFT — horizontal bars */}
        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">Tasks per assignee</div>
              <div className="card-sub">Counted once per person · multi-assigned tasks split</div>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            {rows.map(r => (
              <LoadBar key={r.id} row={r} />
            ))}
          </div>

          {/* Threshold legend */}
          <div style={{ marginTop: 22, paddingTop: 16, borderTop: '1px solid var(--border-1)' }}>
            <div className="section-eyebrow" style={{ marginBottom: 10 }}>Load thresholds</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, fontSize: 11 }}>
              <ThresholdChip color="var(--status-danger)" label="Critical" sub="> 10 tasks · > 3 overdue" />
              <ThresholdChip color="var(--brand-orange)"  label="Watch"    sub="6–10 tasks · 1–2 overdue" />
              <ThresholdChip color="var(--garden-green)"  label="Healthy"  sub="3–5 tasks" />
              <ThresholdChip color="var(--sage-deep)"     label="Available" sub="< 3 tasks" />
            </div>
          </div>
        </div>

        {/* RIGHT — table with load badge */}
        <div className="card" style={{ overflow: 'hidden' }}>
          <div className="card-head">
            <div>
              <div className="card-title">Load status</div>
              <div className="card-sub">3 named users across 12 tasks · {sharedTasks} shared</div>
            </div>
            <span className="pill pill-progress">0 unassigned</span>
          </div>

          <table className="dtable">
            <thead>
              <tr>
                <th>Assignee</th>
                <th className="right">Tasks</th>
                <th className="right">In&nbsp;prog</th>
                <th className="right">Due tmrw</th>
                <th className="right">Load</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(r => {
                const a = ASSIGNEES[r.id];
                const loadColor = r.status === 'Critical' ? 'var(--status-danger)'
                  : r.status === 'Watch' ? 'var(--brand-orange)'
                  : r.status === 'Healthy' ? 'var(--garden-green)'
                  : 'var(--sage-deep)';
                const loadSoft = r.status === 'Watch' ? 'var(--brand-orange-soft)'
                  : r.status === 'Healthy' ? 'var(--garden-green-soft)'
                  : 'var(--bg-muted)';
                return (
                  <tr key={r.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <AssigneeAvatar id={r.id} size={28} />
                        <div>
                          <div style={{ fontWeight: 600, display: 'flex', alignItems: 'center', gap: 6 }}>
                            {a.name}
                            {a.you && <span style={{
                              fontSize: 10, fontWeight: 500, padding: '1px 7px',
                              background: 'var(--brand-orange-soft)', color: 'var(--brand-orange-press)',
                              borderRadius: 999,
                            }}>You</span>}
                          </div>
                          <div style={{ fontSize: 11, color: 'var(--fg-3)' }}>{a.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="right num" style={{ fontWeight: 700 }}>{r.total}</td>
                    <td className="right num">{r.prog}</td>
                    <td className="right num" style={{ color: r.due > 0 ? 'var(--brand-orange-press)' : 'var(--fg-3)', fontWeight: r.due > 0 ? 700 : 400 }}>{r.due}</td>
                    <td className="right">
                      <span className="pill" style={{ background: loadSoft, color: loadColor }}>
                        <span className="dot" style={{ background: loadColor }} />
                        {r.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

function LoadBar({ row }) {
  const a = ASSIGNEES[row.id];
  const max = 10;
  const pct = (row.total / max) * 100;
  const color = row.status === 'Watch' ? 'var(--brand-orange)'
    : row.status === 'Healthy' ? 'var(--garden-green)'
    : 'var(--sage-deep)';
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '160px 1fr 70px', gap: 14, alignItems: 'center' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <AssigneeAvatar id={row.id} size={32} />
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--fg-1)', display: 'flex', alignItems: 'center', gap: 6 }}>
            {a.name}
            {a.you && <span style={{
              fontSize: 9, fontWeight: 500, padding: '1px 6px',
              background: 'var(--brand-orange-soft)', color: 'var(--brand-orange-press)',
              borderRadius: 999, letterSpacing: '0.04em', textTransform: 'uppercase',
            }}>You</span>}
          </div>
          <div style={{ fontSize: 11, color: 'var(--fg-3)' }}>{row.status}</div>
        </div>
      </div>
      <div style={{ position: 'relative' }}>
        <div className="bar-track" style={{ height: 18 }}>
          <div style={{ width: `${pct}%`, background: color, borderRadius: 999, display: 'flex', alignItems: 'center', justifyContent: 'flex-end', paddingRight: 8 }}>
            <span className="num" style={{ color: '#fff', fontSize: 11, fontWeight: 700 }}>{row.total}</span>
          </div>
        </div>
        {/* tick marks */}
        <div style={{ position: 'absolute', top: -4, left: 0, right: 0, height: 4, pointerEvents: 'none' }}>
          {[3, 5, 10].map(n => (
            <span key={n} style={{
              position: 'absolute', left: `${(n / max) * 100}%`,
              width: 1, height: 4, background: 'var(--border-2)',
            }} />
          ))}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4, fontSize: 10, color: 'var(--fg-4)' }}>
          <span>0</span><span>3</span><span>5</span><span>10</span>
        </div>
      </div>
      <div className="num" style={{ textAlign: 'right', fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--fg-1)' }}>
        {row.total}
      </div>
    </div>
  );
}

function ThresholdChip({ color, label, sub }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', gap: 4,
      padding: '8px 10px',
      background: 'var(--bg-muted)', borderRadius: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ width: 8, height: 8, borderRadius: 999, background: color }} />
        <span style={{ fontWeight: 700, color: 'var(--fg-1)' }}>{label}</span>
      </div>
      <span style={{ color: 'var(--fg-3)' }} className="num">{sub}</span>
    </div>
  );
}

Object.assign(window, { LoadSection });
