// 1.1 — Here's where we stand. Metric cards 3-up + status donut.

function HealthSection() {
  return (
    <section data-screen-label="1.1 Health" id="sec-health">
      <SectionHeader
        eyebrow="1.1 · Health"
        title="Here’s where we stand"
        question="Are we OK? The fewest possible numbers, plus a viscerally clear donut."
        fields={['Status']} />

      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 }}>
        {/* LEFT — three metric tiles + completion bar */}
        <div className="card">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 0 }}>
            <MetricTile
              eyebrow="Total tracked"
              number="12"
              foot="across 4 portfolios" />
            <MetricTile
              eyebrow="In progress"
              number="4"
              numColor="var(--garden-green)"
              foot="33.3% of all tasks"
              divider />
            <MetricTile
              eyebrow="Not started"
              number="6"
              numColor="var(--soil-soft)"
              foot="half the backlog untouched"
              divider />
          </div>

          <div style={{
            marginTop: 28, padding: '20px 4px 0',
            borderTop: '1px solid var(--border-1)',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
              <div>
                <div className="section-eyebrow" style={{ marginBottom: 4 }}>Completion rate</div>
                <div className="num" style={{ fontSize: 36, fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--fg-1)', lineHeight: 1 }}>
                  16.7<span style={{ fontSize: 22, color: 'var(--fg-3)' }}>%</span>
                </div>
              </div>
              <div style={{ fontSize: 12, color: 'var(--fg-2)' }}>
                <span className="num" style={{ color: 'var(--fg-1)', fontWeight: 700 }}>2</span> of 12 tasks marked Done
              </div>
            </div>
            <div className="bar-track" style={{ height: 14 }}>
              <div className="bar-segment done"      style={{ width: '16.7%' }} />
              <div className="bar-segment progress"  style={{ width: '33.3%' }} />
              <div className="bar-segment notstarted" style={{ width: '50%' }} />
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 12, fontSize: 11, color: 'var(--fg-2)' }}>
              <span><b className="num" style={{ color: 'var(--garden-green-press)' }}>2</b> Done · 16.7%</span>
              <span><b className="num" style={{ color: 'var(--garden-green)' }}>4</b> In progress · 33.3%</span>
              <span><b className="num" style={{ color: 'var(--soil-soft)' }}>6</b> Not started · 50.0%</span>
            </div>
          </div>
        </div>

        {/* RIGHT — status donut */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column' }}>
          <div className="card-head">
            <div>
              <div className="card-title">Status split</div>
              <div className="card-sub">Half the backlog hasn’t been touched</div>
            </div>
            <span className="pill pill-notstarted"><Icon name="dot" size={10} /> 12 tasks</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 24, flex: 1 }}>
            <MiniDonut
              size={170}
              thickness={26}
              segments={[
                { value: 2, color: '#6B8E5A' },
                { value: 4, color: '#2C9653' },
                { value: 6, color: '#B6C3B9' },
              ]}
              centerLabel="50%"
              centerSub="not started"
            />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, flex: 1 }}>
              <DonutLegendRow color="#6B8E5A" label="Done" value="2" pct="17%" />
              <DonutLegendRow color="#2C9653" label="In progress" value="4" pct="33%" />
              <DonutLegendRow color="#B6C3B9" label="Not started" value="6" pct="50%" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function MetricTile({ eyebrow, number, foot, numColor, divider }) {
  return (
    <div style={{
      padding: '0 18px',
      borderLeft: divider ? '1px solid var(--border-1)' : undefined,
    }}>
      <div className="section-eyebrow" style={{ marginBottom: 6 }}>{eyebrow}</div>
      <div className="num" style={{
        fontSize: 52, fontWeight: 700, letterSpacing: '-0.03em',
        color: numColor || 'var(--fg-1)', lineHeight: 1,
      }}>{number}</div>
      <div style={{ fontSize: 12, color: 'var(--fg-3)', marginTop: 8 }}>{foot}</div>
    </div>
  );
}

function DonutLegendRow({ color, label, value, pct }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13 }}>
      <span style={{ width: 12, height: 12, borderRadius: 4, background: color }} />
      <span style={{ flex: 1, color: 'var(--fg-1)', fontWeight: 500 }}>{label}</span>
      <span className="num" style={{ color: 'var(--fg-1)', fontWeight: 700, minWidth: 24, textAlign: 'right' }}>{value}</span>
      <span className="num" style={{ color: 'var(--fg-3)', fontSize: 11, minWidth: 38, textAlign: 'right' }}>{pct}</span>
    </div>
  );
}

Object.assign(window, { HealthSection });
