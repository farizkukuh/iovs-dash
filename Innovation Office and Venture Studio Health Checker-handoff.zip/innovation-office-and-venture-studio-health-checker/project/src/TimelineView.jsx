// View 2 — Timeline. Gantt, Sprint progress, Velocity/burndown, Cycle time.

function TimelineView() {
  return (
    <div data-screen-label="Timeline" style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
      <TimelineHero />
      <TaskTimeline />
      <SprintProgress />
      <VelocityBurndown />
      <CycleTime />
    </div>
  );
}

function TimelineHero() {
  return (
    <section>
      <SectionHeader
        eyebrow="View 2 · Timeline"
        title="Chronological audit"
        question="When did things start, when are they due, when were they completed? Sprint throughput over time."
        fields={['Started date', 'Due date', 'Completed date', 'Sprint']} />
    </section>
  );
}

// 2.1 — Gantt
function TaskTimeline() {
  // Timeline span: May 22 (day 0) → May 31 (day 9). Today = May 24 (day 2).
  const TODAY = 2;
  const DAYS = 10;
  const days = Array.from({ length: DAYS }, (_, i) => i);

  // For each task, decide start day, due day, completed day relative to May 22
  const rows = TASKS.map(t => {
    const start = t.started ? dayOfYear(t.started) : null;
    const due = t.due ? dayOfYear(t.due) : null;
    const comp = t.completed ? dayOfYear(t.completed) : null;
    return { ...t, start, due, comp };
  });

  return (
    <section data-screen-label="2.1 Task Timeline" id="sec-gantt">
      <div className="card">
        <div className="card-head">
          <div>
            <div className="card-title">2.1 · Task timeline</div>
            <div className="card-sub">Each row is one task · bar runs from Started → Due · diamond marks Completed</div>
          </div>
          <div style={{ display: 'flex', gap: 14, fontSize: 11 }}>
            <LegendDot color="#2C9653" label="In progress bar" />
            <LegendDot color="#6B8E5A" label="Completed (diamond)" />
            <LegendDot color="#B6C3B9" label="Due marker only" />
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: 0 }}>
          {/* Header row */}
          <div style={{ borderBottom: '1px solid var(--border-1)', padding: '8px 12px 12px', fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--fg-3)', fontWeight: 500 }}>
            Task
          </div>
          <div style={{ position: 'relative', borderBottom: '1px solid var(--border-1)', paddingBottom: 12 }}>
            <div style={{ display: 'grid', gridTemplateColumns: `repeat(${DAYS}, 1fr)`, gap: 0, fontSize: 10, color: 'var(--fg-3)' }}>
              {days.map(d => {
                const date = new Date(2026, 4, 22 + d);
                const wd = date.toLocaleDateString('en-US', { weekday: 'short' });
                const day = date.getDate();
                const isToday = d === TODAY;
                return (
                  <div key={d} style={{
                    textAlign: 'center',
                    color: isToday ? 'var(--garden-green-press)' : 'var(--fg-3)',
                    fontWeight: isToday ? 700 : 500,
                  }}>
                    <div style={{ letterSpacing: '0.08em', textTransform: 'uppercase' }}>{wd}</div>
                    <div className="num" style={{ fontSize: 12, color: isToday ? 'var(--garden-green-press)' : 'var(--fg-1)', fontWeight: 700 }}>{day}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Rows */}
          {rows.map((r, i) => (
            <React.Fragment key={r.id}>
              <div style={{
                padding: '10px 12px', borderBottom: i === rows.length - 1 ? 0 : '1px solid var(--border-1)',
                display: 'flex', alignItems: 'center', gap: 8, minWidth: 0,
              }}>
                <AvatarGroup ids={r.assignees} size={22} />
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--fg-1)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.name}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
                    <PortfolioChip name={r.portfolio} />
                  </div>
                </div>
              </div>
              <GanttBar row={r} days={DAYS} today={TODAY} isLast={i === rows.length - 1} />
            </React.Fragment>
          ))}
        </div>

        <div style={{
          marginTop: 18, padding: 14,
          background: 'var(--bg-muted)', borderRadius: 14,
          fontSize: 12, color: 'var(--fg-2)',
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <Icon name="info" size={14} style={{ color: 'var(--garden-green-press)' }} />
          <div>
            <b style={{ color: 'var(--fg-1)' }}>Deadline concentration risk:</b> 3 tasks pile on <b>May 25</b>, 7 more pile on <b>May 29</b>.
            Tasks without a Started date appear as due-date diamonds only.
          </div>
        </div>
      </div>
    </section>
  );
}

function GanttBar({ row, days, today, isLast }) {
  const cell = `repeat(${days}, 1fr)`;
  const col = (d) => `${d + 1} / ${d + 2}`;
  const statusColor = row.status === 'Done' ? '#6B8E5A' : row.status === 'In progress' ? '#2C9653' : '#B6C3B9';

  return (
    <div style={{
      position: 'relative',
      height: 44,
      borderBottom: isLast ? 0 : '1px solid var(--border-1)',
      display: 'grid', gridTemplateColumns: cell, alignItems: 'center',
      padding: '0 0',
    }}>
      {/* gridlines */}
      {Array.from({ length: days }, (_, d) => (
        <div key={d} style={{
          position: 'absolute', top: 0, bottom: 0,
          left: `calc(${(d / days) * 100}% )`,
          width: 1, background: d === today ? 'rgba(44,150,83,0.3)' : 'var(--border-1)',
        }} />
      ))}

      {/* Bar */}
      {row.start !== null && row.due !== null && (
        <div style={{
          gridColumn: `${row.start + 1} / ${row.due + 2}`,
          height: 18,
          background: row.status === 'Done' ? '#DDE6D2' : 'var(--garden-green-soft)',
          borderRadius: 999,
          position: 'relative',
          display: 'flex', alignItems: 'center', overflow: 'visible',
          margin: '0 4px',
        }}>
          {/* progress fill up to today */}
          {row.status === 'In progress' && (
            <div style={{
              position: 'absolute', left: 0, top: 0, bottom: 0,
              width: `${Math.max(0, Math.min(100, ((today - row.start) / (row.due - row.start)) * 100))}%`,
              background: statusColor, borderRadius: 999,
            }} />
          )}
          {row.status === 'Done' && (
            <div style={{
              position: 'absolute', left: 0, top: 0, bottom: 0,
              width: '100%',
              background: statusColor, borderRadius: 999, opacity: 0.85,
            }} />
          )}
        </div>
      )}

      {/* Completed diamond */}
      {row.comp !== null && (
        <div style={{
          position: 'absolute',
          left: `calc(${(row.comp / days) * 100}% + ${100 / days / 2}%)`,
          top: '50%', transform: 'translate(-50%, -50%) rotate(45deg)',
          width: 10, height: 10, background: '#6B8E5A',
          border: '2px solid #fff', boxShadow: '0 1px 3px rgba(0,0,0,0.12)',
        }} />
      )}

      {/* Due diamond for not-started or no start */}
      {row.start === null && row.due !== null && (
        <div style={{
          position: 'absolute',
          left: `calc(${(row.due / days) * 100}% + ${100 / days / 2}%)`,
          top: '50%', transform: 'translate(-50%, -50%)',
          padding: '2px 8px', background: '#B6C3B9', color: '#fff',
          fontSize: 10, fontWeight: 700, borderRadius: 999, letterSpacing: '0.04em',
        }}>
          DUE
        </div>
      )}

      {/* No date marker */}
      {row.due === null && (
        <div style={{
          position: 'absolute', right: -6, top: '50%', transform: 'translateY(-50%)',
          fontSize: 10, color: 'var(--status-danger)', fontWeight: 700,
          display: 'inline-flex', alignItems: 'center', gap: 4,
        }}>
          <Icon name="alert" size={10} />No date
        </div>
      )}

      {/* Today line */}
      <div style={{
        position: 'absolute',
        left: `${(today / days) * 100}%`,
        top: -2, bottom: -2, width: 2,
        background: 'var(--garden-green)', borderRadius: 1,
      }} />
    </div>
  );
}

function LegendDot({ color, label }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, color: 'var(--fg-2)' }}>
      <span style={{ width: 10, height: 10, borderRadius: 3, background: color }} />{label}
    </span>
  );
}

// 2.2 — Sprint progress
function SprintProgress() {
  const sprints = [
    { name: 'Sprint 1', range: 'May 22 – Jun 4', total: 12, done: 2, prog: 4, ns: 6, pct: 16.7, active: true },
    { name: 'Sprint 2', range: 'Jun 5 – Jun 18',  total: 0,  done: 0, prog: 0, ns: 0, pct: null, active: false, future: true },
    { name: 'Sprint 3', range: 'Jun 19 – Jul 2',  total: 0,  done: 0, prog: 0, ns: 0, pct: null, active: false, future: true },
  ];
  return (
    <section data-screen-label="2.2 Sprint Progress" id="sec-sprint">
      <div className="card">
        <div className="card-head">
          <div>
            <div className="card-title">2.2 · Sprint progress</div>
            <div className="card-sub">Are we shipping more tasks each sprint, or is the backlog growing?</div>
          </div>
          <Legend items={[
            { color: '#6B8E5A', label: 'Done' },
            { color: '#2C9653', label: 'In progress' },
            { color: '#B6C3B9', label: 'Not started' },
          ]} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {sprints.map(s => (
            <SprintCard key={s.name} sprint={s} />
          ))}
        </div>
      </div>
    </section>
  );
}

function SprintCard({ sprint }) {
  if (sprint.future) {
    return (
      <div style={{
        padding: 20,
        background: 'var(--bg-muted)',
        border: '1px dashed var(--border-2)',
        borderRadius: 'var(--radius-lg)',
        display: 'flex', flexDirection: 'column', gap: 8,
        color: 'var(--fg-3)',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--fg-2)' }}>{sprint.name}</div>
          <span style={{ fontSize: 10, padding: '3px 8px', background: 'var(--bg-elevated)', borderRadius: 999, color: 'var(--fg-3)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Upcoming</span>
        </div>
        <div style={{ fontSize: 12 }}>{sprint.range}</div>
        <div style={{ fontSize: 11, marginTop: 8 }}>Populates automatically as tasks start. Sprint is derived from Started date — no manual input.</div>
      </div>
    );
  }
  return (
    <div style={{
      padding: 20,
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-1)',
      borderRadius: 'var(--radius-lg)',
      display: 'flex', flexDirection: 'column', gap: 12,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--fg-1)' }}>{sprint.name}</div>
          <div style={{ fontSize: 11, color: 'var(--fg-3)' }}>{sprint.range}</div>
        </div>
        <span className="pill pill-progress"><span className="dot" />Active</span>
      </div>
      <div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
          <span className="num" style={{ fontSize: 32, fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--fg-1)' }}>{sprint.pct}%</span>
          <span style={{ fontSize: 12, color: 'var(--fg-3)' }}>completion</span>
        </div>
      </div>
      {/* Stacked bar */}
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 110 }}>
        <SprintColumn label="Done" color="#6B8E5A" n={sprint.done} max={sprint.total} />
        <SprintColumn label="In prog" color="#2C9653" n={sprint.prog} max={sprint.total} />
        <SprintColumn label="Not started" color="#B6C3B9" n={sprint.ns} max={sprint.total} />
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--fg-3)' }}>
        <span><b style={{ color: 'var(--fg-1)' }}>{sprint.total}</b> total</span>
        <span><b style={{ color: 'var(--fg-1)' }}>{sprint.done}</b> done · <b style={{ color: 'var(--fg-1)' }}>{sprint.prog}</b> active · <b style={{ color: 'var(--fg-1)' }}>{sprint.ns}</b> waiting</span>
      </div>
    </div>
  );
}

function SprintColumn({ label, color, n, max }) {
  const pct = max > 0 ? (n / max) * 100 : 0;
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, height: '100%' }}>
      <div style={{ flex: 1, width: '100%', display: 'flex', alignItems: 'flex-end' }}>
        <div style={{
          width: '100%', minHeight: 4,
          height: `${pct}%`, background: color, borderRadius: '8px 8px 0 0',
          display: 'flex', justifyContent: 'center', alignItems: 'flex-start',
          padding: '6px 0 0', color: '#fff', fontSize: 12, fontWeight: 700,
        }} className="num">{n}</div>
      </div>
      <div style={{ fontSize: 10, color: 'var(--fg-3)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>{label}</div>
    </div>
  );
}

// 2.3 — Velocity + burndown
function VelocityBurndown() {
  return (
    <section data-screen-label="2.3 Velocity" id="sec-velocity">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">2.3a · Velocity</div>
              <div className="card-sub">Tasks completed per day — direction over time</div>
            </div>
            <span className="pill pill-notstarted">Sparse · 2 points</span>
          </div>
          <VelocityChart />
        </div>

        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">2.3b · Burndown · Sprint 1</div>
              <div className="card-sub">Remaining tasks vs. ideal pace</div>
            </div>
            <span className="pill pill-progress"><span className="dot" />Day 3 of 14</span>
          </div>
          <BurndownChart />
        </div>
      </div>
    </section>
  );
}

function VelocityChart() {
  const days = [
    { d: 'May 22', n: 2 }, { d: 'May 23', n: 0 }, { d: 'May 24', n: 0 },
    { d: 'May 25', n: 0 }, { d: 'May 26', n: 0 }, { d: 'May 27', n: 0 },
  ];
  const w = 460, h = 180, pad = 24;
  const xs = days.map((_, i) => pad + ((w - pad * 2) / (days.length - 1)) * i);
  const max = 3;
  const yOf = n => h - pad - (n / max) * (h - pad * 2);
  const linePath = days.map((d, i) => `${i === 0 ? 'M' : 'L'} ${xs[i]} ${yOf(d.n)}`).join(' ');
  const areaPath = linePath + ` L ${xs[xs.length-1]} ${h - pad} L ${xs[0]} ${h - pad} Z`;
  return (
    <div>
      <svg viewBox={`0 0 ${w} ${h}`} width="100%" style={{ display: 'block' }}>
        {/* gridlines */}
        {[0, 1, 2, 3].map(t => (
          <line key={t}
            x1={pad} x2={w - pad}
            y1={yOf(t)} y2={yOf(t)}
            stroke="var(--border-1)" strokeDasharray="3 4" />
        ))}
        <defs>
          <linearGradient id="velArea" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#2C9653" stopOpacity="0.22" />
            <stop offset="100%" stopColor="#2C9653" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={areaPath} fill="url(#velArea)" />
        <path d={linePath} stroke="#2C9653" strokeWidth="2.5" fill="none" />
        {days.map((d, i) => (
          <g key={i}>
            <circle cx={xs[i]} cy={yOf(d.n)} r={d.n > 0 ? 5 : 3}
              fill={d.n > 0 ? '#2C9653' : '#fff'} stroke="#2C9653" strokeWidth="2" />
            {d.n > 0 && (
              <text x={xs[i]} y={yOf(d.n) - 12} textAnchor="middle" fontSize="11" fontWeight="700" fill="#1E6739" className="num">{d.n}</text>
            )}
          </g>
        ))}
        {/* x labels */}
        {days.map((d, i) => (
          <text key={i} x={xs[i]} y={h - 6} textAnchor="middle" fontSize="10" fill="#9B8A82" className="num">{d.d}</text>
        ))}
        {/* y labels */}
        {[0, 1, 2, 3].map(t => (
          <text key={t} x={pad - 8} y={yOf(t) + 3} textAnchor="end" fontSize="10" fill="#9B8A82" className="num">{t}</text>
        ))}
      </svg>
      <div style={{ fontSize: 12, color: 'var(--fg-2)', marginTop: 8 }}>
        <b style={{ color: 'var(--fg-1)' }}>2 tasks completed on day 1</b>, none since. Line is flat after the initial burst — meaningful after 2+ weeks of data.
      </div>
    </div>
  );
}

function BurndownChart() {
  const total = 12;
  const days = 14;
  // Ideal: 12 → 0 linear. Actual: 12 → 10 → 10 → 10 (today, day 3)
  const w = 460, h = 180, pad = 24;
  const xs = Array.from({ length: days + 1 }, (_, i) => pad + ((w - pad * 2) / days) * i);
  const yOf = n => h - pad - (n / total) * (h - pad * 2);

  // Actual: known up to day 2 (today)
  const actualPoints = [12, 10, 10, 10];
  const idealPath = `M ${xs[0]} ${yOf(total)} L ${xs[days]} ${yOf(0)}`;
  const actualPath = actualPoints.map((v, i) => `${i === 0 ? 'M' : 'L'} ${xs[i]} ${yOf(v)}`).join(' ');

  return (
    <div>
      <svg viewBox={`0 0 ${w} ${h}`} width="100%" style={{ display: 'block' }}>
        {[0, 3, 6, 9, 12].map(t => (
          <line key={t} x1={pad} x2={w - pad} y1={yOf(t)} y2={yOf(t)} stroke="var(--border-1)" strokeDasharray="3 4" />
        ))}
        <path d={idealPath} stroke="#B6C3B9" strokeWidth="1.5" strokeDasharray="6 5" fill="none" />
        <path d={actualPath} stroke="#E27000" strokeWidth="2.5" fill="none" />
        {actualPoints.map((v, i) => (
          <circle key={i} cx={xs[i]} cy={yOf(v)} r="4" fill="#E27000" stroke="#fff" strokeWidth="2" />
        ))}
        {/* today line */}
        <line x1={xs[3]} x2={xs[3]} y1={pad} y2={h - pad} stroke="#2C9653" strokeWidth="2" strokeDasharray="2 4" />
        <text x={xs[3]} y={pad - 4} textAnchor="middle" fontSize="9" fill="#2C9653" fontWeight="700">TODAY</text>

        {[0, 3, 6, 9, 12].map(t => (
          <text key={t} x={pad - 8} y={yOf(t) + 3} textAnchor="end" fontSize="10" fill="#9B8A82" className="num">{t}</text>
        ))}
        {['May 22', 'May 25', 'May 29', 'Jun 1', 'Jun 4'].map((d, i) => (
          <text key={d} x={xs[i * 3 + (i === 4 ? 1 : 0)] || xs[i * 3]} y={h - 6} textAnchor="middle" fontSize="10" fill="#9B8A82" className="num">{d}</text>
        ))}
      </svg>
      <div style={{ display: 'flex', gap: 14, fontSize: 11, marginTop: 6 }}>
        <LegendDot color="#E27000" label="Actual remaining" />
        <LegendDot color="#B6C3B9" label="Ideal pace" />
      </div>
      <div style={{ fontSize: 12, color: 'var(--brand-orange-press)', marginTop: 8 }}>
        <Icon name="alert" size={11} style={{ verticalAlign: -1 }} /> Actual line is <b>3 tasks above ideal</b> after day 3. Backlog has not moved since May 22.
      </div>
    </div>
  );
}

// 2.4 — Cycle time
function CycleTime() {
  return (
    <section data-screen-label="2.4 Cycle Time" id="sec-cycle">
      <div className="card">
        <div className="card-head">
          <div>
            <div className="card-title">2.4 · Cycle time</div>
            <div className="card-sub">Days from Started → Completed · surfaces tasks sitting In progress too long</div>
          </div>
          <span className="pill pill-notstarted">Needs data · 2 points</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 22 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, height: 140 }}>
              {[
                { d: 'Same day', n: 2 }, { d: '1 d', n: 0 }, { d: '2 d', n: 0 },
                { d: '3 d', n: 0 }, { d: '4 d', n: 0 }, { d: '5 d', n: 0 },
                { d: '6 d', n: 0 }, { d: '7 d', n: 0 }, { d: '8 d+', n: 0 },
              ].map((b, i) => (
                <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                  <div style={{
                    width: '100%', height: `${b.n * 50}px`, minHeight: 6,
                    background: b.n > 0 ? '#2C9653' : 'var(--bg-muted)',
                    borderRadius: '8px 8px 0 0',
                    display: 'flex', justifyContent: 'center', alignItems: 'flex-start',
                    color: '#fff', fontSize: 11, fontWeight: 700, paddingTop: 6,
                  }} className="num">
                    {b.n > 0 ? b.n : ''}
                  </div>
                  <div style={{ fontSize: 10, color: 'var(--fg-3)' }}>{b.d}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{
            padding: 18, background: 'var(--garden-green-wash)',
            border: '1px solid var(--garden-green-soft)',
            borderRadius: 'var(--radius-md)', display: 'flex', flexDirection: 'column', gap: 12,
          }}>
            <div className="section-eyebrow">Completed tasks · cycle log</div>
            {[
              { name: 'In-depth study Chickin',     s: 'May 22', e: 'May 22', d: '0 days' },
              { name: 'Set up workflow · Claude+Notion', s: 'May 22', e: 'May 22', d: '0 days' },
            ].map((t, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: '#fff', borderRadius: 12 }}>
                <span style={{ width: 8, height: 8, borderRadius: 999, background: '#6B8E5A' }} />
                <div style={{ flex: 1, fontSize: 12, fontWeight: 500, color: 'var(--fg-1)' }}>{t.name}</div>
                <div style={{ fontSize: 11, color: 'var(--fg-3)' }} className="num">{t.s} → {t.e}</div>
                <span className="pill pill-done num" style={{ fontWeight: 700 }}>{t.d}</span>
              </div>
            ))}
            <div style={{ fontSize: 11, color: 'var(--fg-2)', marginTop: 4 }}>
              Both same-day. Distribution gains shape after 5+ completed tasks.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { TimelineView });
