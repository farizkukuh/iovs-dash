// Data — pulled from Notion: IOVS - Task Tracker
// Database: https://www.notion.so/36881eaa07d980c2b23ac25b4085f9eb
// Last pulled 2026-05-24
const PORTFOLIOS = {
  'IOVS Function': { color: '#2C9653', soft: '#D6ECDE' },
  'Harves+':       { color: '#B58750', soft: '#E2C9AC' },
  'Aquila - AI BOX': { color: '#5C7A8C', soft: '#D9E2E8' },
  'Floxx':         { color: '#8FA294', soft: '#D7DED9' },
};

// Notion user IDs mapped to A/B/C for backward compat
const ASSIGNEES = {
  'A': { name: 'Kukuh Fariz',    email: 'farizkukuh.social@gmail.com', color: '#E27000', you: true,  notionId: 'a90ac1c7-5117-4d25-b8f5-38dc19c80cd6' },
  'B': { name: 'Indra P',        email: 'indra.pramana@japfa.com',     color: '#5C7A8C', notionId: '198d872b-594c-81d4-a78d-00021c1fcc29' },
  'C': { name: 'Dhanti Annisa',  email: 'hardhanti.annisa@japfa.com',  color: '#B58750', notionId: '5dc165bc-7e46-443a-9c9f-67a970ae458d' },
};

// 12 tasks — exact rows from Notion, sourced via MCP fetch
const TASKS = [
  { id: 1,  name: 'In-depth study Chickin',                            portfolio: 'Floxx',           status: 'Done',        priority: 'Medium', assignees: ['B'],           started: '2026-05-22', due: '2026-05-29', completed: '2026-05-22', sprint: 'Sprint 1' },
  { id: 2,  name: 'Set up workflow in Claude & Notion',                portfolio: 'IOVS Function',   status: 'Done',        priority: 'Medium', assignees: ['A'],           started: '2026-05-22', due: '2026-05-29', completed: '2026-05-22', sprint: 'Sprint 1' },
  { id: 3,  name: 'IOVS organization structure',                       portfolio: 'IOVS Function',   status: 'In progress', priority: 'Medium', assignees: ['A', 'B', 'C'], started: '2026-05-22', due: '2026-05-29', completed: null,         sprint: 'Sprint 1' },
  { id: 4,  name: 'Financial projection until 2029',                   portfolio: 'Aquila - AI BOX', status: 'In progress', priority: 'High',   assignees: ['C'],           started: '2026-05-22', due: '2026-05-25', completed: null,         sprint: 'Sprint 1' },
  { id: 5,  name: 'Term Sheet Development Aquila with SGPTech',        portfolio: 'Aquila - AI BOX', status: 'In progress', priority: 'High',   assignees: ['B'],           started: '2026-05-22', due: '2026-05-25', completed: null,         sprint: 'Sprint 1' },
  { id: 6,  name: 'Claude cowork skill for IOVS',                      portfolio: 'IOVS Function',   status: 'In progress', priority: 'High',   assignees: ['A'],           started: '2026-05-22', due: '2026-05-25', completed: null,         sprint: 'Sprint 1' },
  { id: 7,  name: 'In-depth study Jala',                               portfolio: 'Harves+',         status: 'Not started', priority: 'Medium', assignees: ['A'],           started: null,         due: '2026-05-29', completed: null,         sprint: '—' },
  { id: 8,  name: 'JALA Competitive Analysis vs Harves+ (In-Depth)',   portfolio: 'Harves+',         status: 'Not started', priority: 'Medium', assignees: ['A'],           started: null,         due: '2026-05-29', completed: null,         sprint: '—' },
  { id: 9,  name: 'China Market & Floxx Operational Immersion',        portfolio: 'Floxx',           status: 'Not started', priority: 'High',   assignees: ['B'],           started: null,         due: null,         completed: null,         sprint: '—' },
  { id: 10, name: 'Project timeline for each venture',                 portfolio: 'IOVS Function',   status: 'Not started', priority: 'Medium', assignees: ['A', 'B', 'C'], started: null,         due: '2026-05-29', completed: null,         sprint: '—' },
  { id: 11, name: 'Re-work venture plan (incl. ATD commercial plan)',  portfolio: 'Harves+',         status: 'Not started', priority: 'Medium', assignees: ['A', 'B', 'C'], started: null,         due: '2026-05-29', completed: null,         sprint: '—' },
  { id: 12, name: 'Standardized Note-Taking Template',                 portfolio: 'IOVS Function',   status: 'Not started', priority: 'Medium', assignees: ['C'],           started: null,         due: '2026-05-29', completed: null,         sprint: '—' },
];

// Derived assignee load — computed from real data
// Kukuh: 7 tasks (2 in prog, 1 due tmrw) · Indra: 6 (2 in prog, 1 due tmrw) · Dhanti: 5 (2 in prog, 1 due tmrw)
function loadFor(id) {
  const mine = TASKS.filter(t => t.assignees.includes(id));
  return {
    total: mine.length,
    inProgress: mine.filter(t => t.status === 'In progress').length,
    dueTomorrow: mine.filter(t => t.due === '2026-05-25').length,
  };
}

// Quick lookups
const STATUS_META = {
  'Done':        { color: '#6B8E5A', soft: '#DDE6D2', cls: 'pill-done' },
  'In progress': { color: '#2C9653', soft: '#D6ECDE', cls: 'pill-progress' },
  'Not started': { color: '#9B8A82', soft: '#EFEFE7', cls: 'pill-notstarted' },
};

const PRIORITY_META = {
  'High':   { color: '#B14A36', soft: '#F4D7CF', cls: 'pill-high' },
  'Medium': { color: '#C78A2C', soft: '#F7E4C2', cls: 'pill-medium' },
};

// Formatters
function fmtDate(s) {
  if (!s) return '—';
  const d = new Date(s + 'T00:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}
function fmtDateLong(s) {
  if (!s) return 'No date';
  const d = new Date(s + 'T00:00:00');
  return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric' });
}
function dayOfYear(s) {
  // distance from May 22, 2026 in days
  const base = new Date('2026-05-22T00:00:00').getTime();
  const d = new Date(s + 'T00:00:00').getTime();
  return Math.round((d - base) / 86400000);
}

Object.assign(window, {
  PORTFOLIOS, ASSIGNEES, TASKS, STATUS_META, PRIORITY_META,
  fmtDate, fmtDateLong, dayOfYear, loadFor,
});
